import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase, type Profile } from '@/lib/supabase';

type AuthContextType = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (identifier: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string, phone: string, referralCode?: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function genCode(): string {
  return 'SNB' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

function phoneToFakeEmail(phone: string): string {
  const cleaned = phone.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
  return `${cleaned}@snbinvestmining.com`;
}

function normalizeProfile(data: Record<string, unknown> | null): Profile | null {
  if (!data) return null;
  return {
    ...data,
    balance: Number(data.balance) || 0,
    total_invested: Number(data.total_invested) || 0,
    total_profit: Number(data.total_profit) || 0,
    is_admin: Boolean(data.is_admin),
  } as Profile;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (uid: string) => {
    let { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .maybeSingle();

    if (error) {
      console.error('Profile fetch error:', error);
    }

    if (!data) {
      // Profile not found — create it WITHOUT a referral code so we never
      // overwrite an existing code. The RPC uses ON CONFLICT DO UPDATE with
      // referral_code = profiles.referral_code (preserves existing).
      const { error: rpcError } = await supabase.rpc('create_user_profile', {
        p_user_id: uid,
      });
      if (rpcError) {
        console.error('Profile create RPC error:', rpcError);
      }
      // Re-fetch after creation with a small delay for RLS to catch up
      await new Promise((r) => setTimeout(r, 500));
      const refetch = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .maybeSingle();
      data = refetch.data;
      if (refetch.error) {
        console.error('Profile refetch error:', refetch.error);
      }
    }

    if (data) {
      setProfile(normalizeProfile(data));
    } else {
      console.error('Profile still null after create + refetch for uid:', uid);
    }

    const { data: adminResult, error: adminError } = await supabase.rpc('is_current_user_admin');
    if (adminError) {
      console.error('Admin RPC error:', adminError);
      setIsAdmin(false);
    } else {
      setIsAdmin(adminResult === true);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data: { session: s } } = await supabase.auth.getSession();
    if (s?.user) await loadProfile(s.user.id);
  }, [loadProfile]);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(async ({ data: { session: s } }) => {
      if (!mounted) return;
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        await loadProfile(s.user.id);
      }
      if (mounted) setLoading(false);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((event, s) => {
      if (!mounted) return;
      if (event === 'SIGNED_OUT') {
        setSession(null);
        setUser(null);
        setProfile(null);
        setIsAdmin(false);
        setLoading(false);
        return;
      }
      if (event === 'SIGNED_IN' && s) {
        setSession(s);
        setUser(s.user);
        setLoading(true);
        (async () => {
          await loadProfile(s.user.id);
          if (mounted) setLoading(false);
        })();
      }
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signIn = async (identifier: string, password: string) => {
    const email = identifier.includes('@') ? identifier : phoneToFakeEmail(identifier);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return { error: null };
  };

  const signUp = async (email: string, password: string, fullName: string, phone: string, referralCode?: string) => {
    const actualEmail = email.includes('@') ? email : phoneToFakeEmail(phone);
    const { data, error } = await supabase.auth.signUp({ email: actualEmail, password });
    if (error) return { error: error.message };
    if (data.user) {
      const { data: codeData } = await supabase.rpc('generate_referral_code');
      const code = (codeData as string) || genCode();
      const { error: profileError } = await supabase.rpc('create_user_profile', {
        p_user_id: data.user.id,
        p_full_name: fullName,
        p_phone: phone || email,
        p_referral_code: code,
        p_referred_by: referralCode || '',
      });
      if (profileError) {
        console.error('Profile creation RPC error:', profileError);
      }

      if (referralCode) {
        await supabase.rpc('create_referral', {
          p_referrer_code: referralCode,
          p_referred_id: data.user.id,
        });
      }
    }
    return { error: null };
  };

  const signOut = async () => {
    setLoading(true);
    await supabase.auth.signOut();
    setProfile(null);
    setIsAdmin(false);
    setUser(null);
    setSession(null);
    setLoading(false);
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, isAdmin, signIn, signUp, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
