import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { translations, languages, type Lang } from '@/lib/translations';

type LanguageContextType = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
  dir: 'rtl' | 'ltr';
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>('ar');

  useEffect(() => {
    const saved = localStorage.getItem('snb_lang') as Lang | null;
    if (saved && languages.some((l) => l.code === saved)) {
      setLangState(saved);
    }
  }, []);

  useEffect(() => {
    const conf = languages.find((l) => l.code === lang);
    document.documentElement.dir = conf?.dir ?? 'rtl';
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem('snb_lang', l);
  };

  const t = (key: string): string => {
    const dict = translations[lang] ?? translations.ar;
    return dict[key] ?? translations.ar[key] ?? key;
  };

  const dir = languages.find((l) => l.code === lang)?.dir ?? 'rtl';

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLang must be used within LanguageProvider');
  return ctx;
}
