import { useEffect, useState } from 'react';
import { X, Copy, Check, Bitcoin, Coins, Wallet, AlertTriangle, RefreshCw, Send } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';
import { supabase, type DepositAddress } from '@/lib/supabase';

const cryptoIcons: Record<string, typeof Bitcoin> = {
  USDT: Coins, USDC: Coins, TRX: Coins, BTC: Bitcoin, ETH: Wallet, BNB: Wallet, SOL: Wallet,
};

const cryptoColors: Record<string, string> = {
  USDT: 'text-green-400', USDC: 'text-blue-400', TRX: 'text-red-400',
  BTC: 'text-orange-400', ETH: 'text-purple-400', BNB: 'text-yellow-400', SOL: 'text-cyan-400',
};

type Props = {
  open: boolean;
  onClose: () => void;
  selectedPlan?: string;
  onDepositSubmitted: () => void;
};

export default function DepositModal({ open, onClose, onDepositSubmitted }: Props) {
  const { t, lang } = useLang();
  const [addresses, setAddresses] = useState<DepositAddress[]>([]);
  const [selected, setSelected] = useState<DepositAddress | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (open) {
      setError(null);
      setSuccess(false);

      supabase
        .from('deposit_addresses')
        .select('*')
        .eq('is_active', true)
        .order('currency')
        .then(({ data }) => {
          if (data) {
            setAddresses(data as DepositAddress[]);
            if (data.length > 0) setSelected(data[0] as DepositAddress);
          }
        });
    }
  }, [open]);

  if (!open) return null;

  const handleCopy = () => {
    if (selected) {
      navigator.clipboard.writeText(selected.address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDepositDone = async () => {
    setError(null);
    setLoading(true);

    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) {
      setError(lang === 'ar' ? 'غير مسجّل الدخول' : 'Not signed in');
      setLoading(false);
      return;
    }

    const { error: depositError } = await supabase.from('deposits').insert({
      currency: selected?.currency ?? 'USDT',
      amount: 0,
      tx_hash: '',
      sender_wallet: '',
      status: 'pending',
    });

    if (depositError) {
      setError(depositError.message);
      setLoading(false);
      return;
    }

    setSuccess(true);
    setLoading(false);
    setTimeout(() => {
      setSuccess(false);
      onClose();
      onDepositSubmitted();
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div
        className="glass rounded-3xl p-6 md:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold">{t('dep_title')}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {success ? (
          <div className="text-center py-10">
            <div className="w-20 h-20 mx-auto rounded-full bg-primary-500/20 flex items-center justify-center mb-4">
              <Check className="w-10 h-10 text-primary-400" />
            </div>
            <h4 className="text-xl font-bold mb-2">{t('dep_success')}</h4>
            <p className="text-sm text-gray-400 mt-2 max-w-sm mx-auto">{t('dep_auto_verify_note')}</p>
          </div>
        ) : (
          <>
            {/* Step 1: Select currency */}
            <div className="mb-6">
              <label className="text-sm text-gray-400 mb-3 block">{t('dep_select_currency')}</label>
              <div className="grid grid-cols-4 gap-2">
                {addresses.map((addr) => {
                  const Icon = cryptoIcons[addr.currency] ?? Coins;
                  const isActive = selected?.id === addr.id;
                  return (
                    <button
                      key={addr.id}
                      onClick={() => setSelected(addr)}
                      className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all ${
                        isActive
                          ? 'border-primary-500/50 bg-primary-500/10'
                          : 'border-white/5 glass-light hover:bg-white/5'
                      }`}
                    >
                      <Icon className={`w-6 h-6 ${cryptoColors[addr.currency] ?? 'text-gray-400'}`} />
                      <span className="text-xs font-semibold">{addr.currency}</span>
                      <span className="text-[10px] text-gray-500">{addr.network}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Platform deposit address */}
            {selected && (
              <div className="mb-6">
                <label className="text-sm text-gray-400 mb-2 block">
                  {t('dep_wallet_addr')} — {selected.currency} ({selected.network})
                </label>
                <div className="glass-light rounded-xl p-4 flex items-center gap-3">
                  <code className="flex-1 text-xs md:text-sm text-primary-400 font-mono break-all" dir="ltr">
                    {selected.address}
                  </code>
                  <button
                    onClick={handleCopy}
                    className="flex-shrink-0 w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                  >
                    {copied ? <Check className="w-5 h-5 text-primary-400" /> : <Copy className="w-5 h-5 text-gray-400" />}
                  </button>
                </div>
                <div className="flex items-start gap-2 mt-3 bg-amber-500/10 border border-amber-500/20 rounded-xl p-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-300/80">
                    {t('dep_warning')} {selected.network}
                  </p>
                </div>
              </div>
            )}

            {/* Auto-verification note */}
            <div className="flex items-start gap-2 bg-primary-500/10 border border-primary-500/20 rounded-xl p-3 mb-6">
              <RefreshCw className="w-4 h-4 text-primary-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-primary-300/80">
                {t('dep_auto_verify_note')}
              </p>
            </div>

            {error && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-4">
                <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-300">{error}</p>
              </div>
            )}

            {/* Confirm button */}
            <button
              onClick={handleDepositDone}
              disabled={loading || !selected}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-[1.02] disabled:opacity-60"
            >
              {loading ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  {t('dep_done_btn')}
                </>
              )}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
