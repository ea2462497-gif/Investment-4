import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

export default function FAQ() {
  const { t, lang } = useLang();
  const [open, setOpen] = useState<number | null>(0);

  const faqsAr = [
    { q: 'كيفية تسجيل الدخول (Login Password)', a: 'يمكنك تسجيل الدخول باستخدام رقم الهاتف أو البريد الإلكتروني وكلمة المرور التي أنشأتها عند التسجيل. انتقل إلى صفحة تسجيل الدخول، أدخل رقم هاتفك أو بريدك الإلكتروني في الحقل الأول، وكلمة المرور في الحقل الثاني، ثم اضغط على "تسجيل الدخول".' },
    { q: 'كلمة مرور الأمان (Security Password)', a: 'كلمة مرور الأمان هي طبقة حماية إضافية تُطلب عند تنفيذ عمليات حساسة مثل السحب أو تحويل الأرباح. يمكنك تعيينها من إعدادات الحساب في لوحة التحكم. تأكد من اختيار كلمة مرور قوية مختلفة عن كلمة مرور تسجيل الدخول.' },
    { q: 'التواصل مع خدمة العملاء (Customer Service)', a: 'فريق خدمة العملاء متاح على مدار الساعة 24/7. يمكنك التواصل معنا عبر البريد الإلكتروني: support@snbinvestmining.com، أو عبر الهاتف: +966 50 000 0000. كما يمكنك التواصل معنا عبر تيليجرام: @Cfxbl.' },
    { q: 'الورقة البيضاء (White Paper)', a: 'الورقة البيضاء لمنصة SNB Invest Mining توثّق التفاصيل التقنية والمالية للمنصة: آلية التعدين السحابي، توزيع الأرباح، هيكل الخطط، وإجراءات الأمان. توضح أيضاً نموذج العمل والشراكات مع مزارع التعدين. يمكنك طلب نسخة من الورقة البيضاء عبر التواصل مع خدمة العملاء.' },
    { q: 'من نحن (About Us)', a: 'SNB Invest Mining هي منصة تعدين سحابي تأسست لتقديم فرص استثمارية في مجال العملات الرقمية للمستخدمين في الوطن العربي والعالم. نتعامل مع مزارع تعدين حقيقية ونعتمد أحدث تقنيات الأمان لحماية أموال مستخدمينا. نخدم أكثر من 50,000 معدّن نشط في أكثر من 30 دولة.' },
    { q: 'ما هي خطة التعدين المجانية؟', a: 'خطة SNB-0 مجانية تماماً. لا تحتاج لأي استثمار. تربح 1.6 USDT يومياً بمجرد تفعيلها. مثالية للتجربة قبل الاستثمار في الخطط المدفوعة.' },
    { q: 'كيف أحقق أرباحي اليومية؟', a: 'أرباحك تتراكم يومياً في خطة التعدين النشطة. يمكنك تحصيلها كل 24 ساعة بضغطة زر واحد من صفحة التعدين في لوحة التحكم. تُضاف الأرباح مباشرة إلى رصيدك المتاح.' },
    { q: 'كيف أقوم بالإيداع؟', a: 'اذهب إلى صفحة الإيداع، اختر الخطة المناسبة، ثم اختر العملة الرقمية التي تريد الإيداع بها. انسخ عنوان المحفظة المعروض، وافتح محفظتك الرقمية وأرسل المبلغ المطلوب إلى العنوان. بعد التحويل، ارجع إلى صفحة الإيداع وأدخل هاش المعاملة (TxHash) لتأكيد الإيداع.' },
    { q: 'ما هي العملة المستخدمة؟', a: 'جميع الأرباح بالدولار الأمريكي (USDT). يمكنك الإيداع والسحب عبر عملات رقمية متعددة مثل USDT و BTC و ETH و TRX و USDC و BNB و SOL.' },
    { q: 'هل يمكنني الاشتراك في أكثر من خطة؟', a: 'نعم، يمكنك الاشتراك في عدة خطط في نفس الوقت. أرباحك اليومية ستكون مجموع أرباح جميع الخطط النشطة.' },
    { q: 'كم تستغرق معالجة السحب؟', a: 'تتم معالجة طلبات السحب خلال دقائق إلى ساعات قليلة. لا توجد رسوم خفية على عمليات السحب.' },
    { q: 'هل هناك برنامج إحالة؟', a: 'نعم! شارك كود الدعوة الخاص بك واحصل على 5 USDT لكل صديق ينضم ويقوم بالإيداع. كل مستخدم يحصل على كود دعوة فريد يبدأ بـ SNB.' },
  ];

  const faqsEn = [
    { q: 'How to Login (Login Password)', a: 'You can sign in using your phone number or email and the password you created during registration. Go to the login page, enter your phone or email in the first field, your password in the second, and click "Sign In".' },
    { q: 'Security Password', a: 'The security password is an additional protection layer required for sensitive operations like withdrawals or profit transfers. You can set it from your account settings in the dashboard. Make sure to choose a strong password different from your login password.' },
    { q: 'Contact Customer Service', a: 'Our customer service team is available 24/7. You can reach us via email: support@snbinvestmining.com, or by phone: +966 50 000 0000. You can also contact us via Telegram: @Cfxbl.' },
    { q: 'White Paper', a: 'The SNB Invest Mining white paper documents the technical and financial details of the platform: cloud mining mechanism, profit distribution, plan structure, and security procedures. You can request a copy by contacting customer service.' },
    { q: 'About Us', a: 'SNB Invest Mining is a cloud mining platform founded to provide investment opportunities in cryptocurrency for users worldwide. We work with real mining farms and use the latest security technologies. We serve over 50,000 active miners in more than 30 countries.' },
    { q: 'What is the free mining plan?', a: 'The SNB-0 plan is completely free. No investment needed. You earn 1.6 USDT daily upon activation. Perfect for trying before investing in paid plans.' },
    { q: 'How do I collect my daily profits?', a: 'Your profits accumulate daily in your active mining plan. You can claim them every 24 hours with one click from the mining page in your dashboard. Profits are added directly to your available balance.' },
    { q: 'How do I deposit?', a: 'Go to the deposit page, choose your plan, then select the cryptocurrency to deposit. Copy the displayed wallet address, open your crypto wallet and send the required amount. After transferring, return to the deposit page and enter the transaction hash (TxHash) to confirm.' },
    { q: 'What currency is used?', a: 'All profits are in USDT. You can deposit and withdraw via multiple cryptocurrencies including USDT, BTC, ETH, TRX, USDC, BNB, and SOL.' },
    { q: 'Can I subscribe to multiple plans?', a: 'Yes, you can subscribe to multiple plans at the same time. Your daily profit will be the sum of all active plans earnings.' },
    { q: 'How long does withdrawal processing take?', a: 'Withdrawals are processed within minutes to a few hours. There are no hidden fees on withdrawals.' },
    { q: 'Is there a referral program?', a: 'Yes! Share your referral code and get 5 USDT for each friend who joins and makes a deposit. Every user gets a unique referral code starting with SNB.' },
  ];

  const faqs = lang === 'ar' ? faqsAr : faqsEn;

  return (
    <section id="faq" className="py-16 sm:py-24 relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-4">
            <HelpCircle className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-300">{t('faq_badge')}</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold">
            {t('faq_title_1')} <span className="text-gradient-cyan">{t('faq_title_2')}</span>
          </h2>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t('faq_desc')}
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="glass rounded-2xl overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-right hover:bg-white/5 transition-colors"
              >
                <span className="font-semibold text-white text-sm md:text-base">{faq.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-primary-400 flex-shrink-0 transition-transform duration-300 ${
                    open === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`transition-all duration-300 overflow-hidden ${
                  open === i ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <p className="px-5 pb-5 text-gray-400 text-sm leading-relaxed">{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
