import { Star, Quote } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

export default function Testimonials() {
  const { t } = useLang();

  const testimonials = [
    { name: 'Ahmed A.', role: 'Miner — Riyadh', rating: 5, text: 'Amazing platform! Started with the free SNB-0 plan and now on SNB-3. Daily profits arrive on time every 24 hours.' },
    { name: 'Sarah M.', role: 'Trader — Dubai', rating: 5, text: 'I was skeptical about cloud mining, but SNB Invest Mining changed my mind completely. Transparency and speed in claiming profits is remarkable.' },
    { name: 'Khaled S.', role: 'Engineer — Doha', rating: 5, text: 'Best financial decision this year. Started with SNB-2 and my daily earnings cover all my daily expenses entirely.' },
    { name: 'Noura F.', role: 'Financial Advisor — Kuwait', rating: 5, text: 'As a financial expert, I recommend this platform to my clients. Diverse mining plans and daily guaranteed returns. Excellent experience.' },
    { name: 'Omar H.', role: 'Employee — Jeddah', rating: 5, text: 'The free SNB-0 plan gave me 1.6 USDT daily with zero investment! Then I joined SNB-4 and my profits are multiplying.' },
    { name: 'Layla A.', role: 'Entrepreneur — Manama', rating: 5, text: 'The interface is very easy and mining works automatically. I claim my profits every morning and watch my balance grow.' },
  ];

  return (
    <section id="testimonials" className="py-16 sm:py-24 relative">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-4">
            <Star className="w-4 h-4 text-gold-500" />
            <span className="text-sm text-gray-300">{t('test_badge')}</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold">
            {t('test_title_1')} <span className="text-gradient-cyan">{t('test_title_2')}</span>
          </h2>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t('test_desc')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((tm) => (
            <div
              key={tm.name}
              className="glass rounded-2xl p-7 hover:bg-white/8 transition-all duration-300 hover:scale-[1.02] relative group"
            >
              <Quote className="absolute top-6 left-6 w-10 h-10 text-white/5 group-hover:text-white/10 transition-colors" />

              <div className="flex gap-1 mb-4">
                {Array.from({ length: tm.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold-500 text-gold-500" />
                ))}
              </div>

              <p className="text-gray-300 text-sm leading-relaxed mb-6 relative z-10">
                "{tm.text}"
              </p>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-white font-bold text-lg">
                  {tm.name.charAt(0)}
                </div>
                <div>
                  <div className="font-semibold text-white text-sm">{tm.name}</div>
                  <div className="text-xs text-gray-400">{tm.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
