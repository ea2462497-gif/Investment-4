import { Users, DollarSign, Flame, Globe } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useLang } from '@/context/LanguageContext';

function useCountUp(target: number, duration: number, start: boolean) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    let frame: number;
    const step = (ts: number) => {
      if (startTime === null) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setVal(target * eased);
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [target, duration, start]);
  return val;
}

function StatCard({ icon: Icon, value, suffix, labelKey, decimals }: { icon: typeof Users; value: number; suffix: string; labelKey: string; decimals: number }) {
  const { t } = useLang();
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => e.isIntersecting && setVisible(true),
      { threshold: 0.3 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const animated = useCountUp(value, 2000, visible);

  return (
    <div
      ref={ref}
      className="glass-light rounded-2xl p-4 sm:p-6 md:p-8 text-center hover:bg-white/8 transition-all duration-300 hover:scale-105 group"
    >
      <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-primary-500/20 to-accent-500/20 flex items-center justify-center mb-4 group-hover:from-primary-500/30 group-hover:to-accent-500/30 transition-all">
        <Icon className="w-7 h-7 text-primary-400" />
      </div>
      <div className="text-3xl md:text-4xl font-extrabold text-gradient-cyan">
        {animated.toFixed(decimals)}{suffix}
      </div>
      <div className="text-sm text-gray-400 mt-2">{t(labelKey)}</div>
    </div>
  );
}

export default function Stats() {
  const { t } = useLang();
  const stats = [
    { icon: Users, value: 50000, suffix: '+', labelKey: 'stat_miners', decimals: 0 },
    { icon: DollarSign, value: 12, suffix: 'M+', labelKey: 'stat_collected', decimals: 0 },
    { icon: Flame, value: 10, suffix: '', labelKey: 'stat_plans', decimals: 0 },
    { icon: Globe, value: 30, suffix: '+', labelKey: 'stat_countries', decimals: 0 },
  ];

  return (
    <section className="py-12 sm:py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
          {stats.map((s) => (
            <StatCard key={s.labelKey} {...s} />
          ))}
        </div>
      </div>
    </section>
  );
}
