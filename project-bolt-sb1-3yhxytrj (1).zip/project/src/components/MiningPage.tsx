import { useState, useEffect, useCallback, useRef } from 'react';
import { Flame, Loader2, TrendingUp, Check, Coins, Cpu, Activity, Zap, Power } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LanguageContext';
import { supabase, num, type MiningInvestment } from '@/lib/supabase';

const miningPlans = [
  { code: 'SNB-0', invest: 0, daily: 1.6, color: 'from-gray-500 to-gray-700', fire: '🔥' },
  { code: 'SNB-1', invest: 13, daily: 7, color: 'from-green-500 to-green-700', fire: '🔥' },
  { code: 'SNB-2', invest: 49, daily: 28, color: 'from-teal-500 to-teal-700', fire: '🔥' },
  { code: 'SNB-3', invest: 155, daily: 99, color: 'from-cyan-500 to-cyan-700', fire: '🔥' },
  { code: 'SNB-4', invest: 372, daily: 252, color: 'from-blue-500 to-blue-700', fire: '🔥' },
  { code: 'SNB-5', invest: 720, daily: 518, color: 'from-amber-500 to-amber-700', fire: '🔥' },
  { code: 'SNB-6', invest: 1351, daily: 986, color: 'from-orange-500 to-orange-700', fire: '🔥' },
  { code: 'SNB-7', invest: 2783, daily: 2059, color: 'from-red-500 to-red-700', fire: '🔥' },
  { code: 'SNB-8', invest: 5162, daily: 3871, color: 'from-pink-500 to-pink-700', fire: '🔥' },
  { code: 'SNB-9', invest: 9358, daily: 7112, color: 'from-gold-500 to-gold-600', fire: '🔥' },
];

export default function MiningPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { t, lang } = useLang();
  const [mining, setMining] = useState<MiningInvestment[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';

  const fetchMining = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('mining_investments')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setMining((data as MiningInvestment[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchMining(); }, [fetchMining]);

  const handleSubscribe = async (plan: typeof miningPlans[0]) => {
    if (!user) return;
    const currentBalance = Number(profile?.balance) || 0;
    if (plan.invest > 0 && currentBalance < plan.invest) {
      alert(lang === 'ar' ? `رصيدك غير كافٍ. تحتاج إلى ${plan.invest} USDT على الأقل. قم بالإيداع أولاً.` : `Insufficient balance. You need at least ${plan.invest} USDT. Deposit first.`);
      return;
    }
    setActionLoading(true);

    // Both free and paid plans: insert mining investment directly.
    // For SNB-0, a database trigger auto-credits 1.6 USDT on insert.
    if (plan.invest > 0) {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ balance: currentBalance - plan.invest })
        .eq('id', user.id);
      if (updateError) {
        alert(updateError.message);
        setActionLoading(false);
        return;
      }
    }

    const { error } = await supabase.from('mining_investments').insert({
      user_id: user.id,
      plan_code: plan.code,
      invest_amount: plan.invest,
      daily_earn: plan.daily,
      status: 'active',
      last_claim: new Date().toISOString(),
    });

    if (error) {
      if (error.code === '23505') {
        alert(lang === 'ar' ? `أنت مشترك بالفعل في ${plan.code}` : `Already subscribed to ${plan.code}`);
      } else {
        alert(error.message);
      }
      setActionLoading(false);
      return;
    }

    await supabase.from('transactions').insert({
      user_id: user.id,
      type: 'mining_investment',
      amount: plan.invest,
      status: 'completed',
      description: `${t('mining_subscribe')} ${plan.code}`,
    });

    alert(lang === 'ar'
      ? `تم الاشتراك في ${plan.code} بنجاح! ستربح ${plan.daily} USDT يومياً.`
      : `Subscribed to ${plan.code}! You'll earn ${plan.daily} USDT daily.`);
    setActionLoading(false);
    fetchMining();
    refreshProfile();
  };

  const handleClaim = async (inv: MiningInvestment) => {
    const now = new Date();
    const lastClaim = new Date(inv.last_claim);
    const hoursSinceClaim = (now.getTime() - lastClaim.getTime()) / (1000 * 60 * 60);

    if (hoursSinceClaim < 24) {
      const remaining = Math.ceil(24 - hoursSinceClaim);
      alert(lang === 'ar' ? `يمكنك المطالبة بالأرباح بعد ${remaining} ساعة من آخر مطالبة.` : `You can claim profits after ${remaining} hours.`);
      return;
    }

    const daysPassed = Math.floor(hoursSinceClaim / 24);
    const earnings = num(inv.daily_earn) * daysPassed;
    if (earnings <= 0) return;

    setActionLoading(true);
    const { error: updateError } = await supabase
      .from('mining_investments')
      .update({
        last_claim: now.toISOString(),
        total_earned: (Number(inv.total_earned) || 0) + earnings,
      })
      .eq('id', inv.id);

    if (updateError) {
      alert(updateError.message);
      setActionLoading(false);
      return;
    }

    const currentBalance = Number(profile?.balance) || 0;
    const currentProfit = Number(profile?.total_profit) || 0;
    await supabase.from('profiles').update({
      balance: currentBalance + earnings,
      total_profit: currentProfit + earnings,
    }).eq('id', user!.id);

    await supabase.from('transactions').insert({
      user_id: user!.id,
      type: 'mining_profit',
      amount: earnings,
      status: 'completed',
      description: `${t('mining_claim')} ${inv.plan_code} (${daysPassed} ${t('mining_day')})`,
    });

    alert(lang === 'ar' ? `تم تحصيل ${earnings} USDT من خطة ${inv.plan_code}!` : `Collected ${earnings} USDT from ${inv.plan_code}!`);
    setActionLoading(false);
    fetchMining();
    refreshProfile();
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString(locale, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

  const activeMining = mining.filter(m => m.status === 'active');
  const totalDaily = activeMining.reduce((s, m) => s + num(m.daily_earn), 0);
  const totalEarned = mining.reduce((s, m) => s + num(m.total_earned), 0);
  const perSecond = totalDaily / 86400;
  const isRunning = activeMining.length > 0;
  const startRef = useRef<number>(Date.now());
  const [liveEarnings, setLiveEarnings] = useState(0);
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setUptime(Math.floor((Date.now() - startRef.current) / 1000));
      setLiveEarnings(prev => prev + perSecond);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, perSecond]);

  useEffect(() => {
    if (!isRunning) {
      setLiveEarnings(0);
      setUptime(0);
    }
  }, [isRunning]);

  const formatUptime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const formatHashrate = (daily: number) => {
    const th = daily * 12.5;
    if (th >= 1000) return `${(th / 1000).toFixed(2)} PH/s`;
    return `${th.toFixed(1)} TH/s`;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-2">
        <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-3">
          <Flame className="w-4 h-4 text-orange-400" />
          <span className="text-sm text-gray-300">{t('mining_badge')}</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-extrabold">{t('mining_title_1')} <span className="text-gradient-gold">{t('mining_title_2')}</span></h2>
        <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">{t('mining_desc')}</p>
      </div>

      {/* Mining Machine Widget */}
      <div className={`relative glass rounded-3xl p-6 overflow-hidden ${isRunning ? 'glow-primary' : ''}`}>
        {/* Animated background grid */}
        <div className="absolute inset-0 grid-pattern opacity-50 pointer-events-none" />
        {/* Scanning line effect when running */}
        {isRunning && (
          <div className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent animate-scan-line pointer-events-none" />
        )}

        <div className="relative flex flex-col lg:flex-row items-center gap-6">
          {/* Machine icon / visual */}
          <div className="relative flex-shrink-0">
            <div className={`w-24 h-24 rounded-2xl flex items-center justify-center ${isRunning ? 'bg-gradient-to-br from-cyan-500/20 to-blue-600/20' : 'glass-light'}`}>
              <Cpu className={`w-12 h-12 ${isRunning ? 'text-cyan-400 animate-pulse' : 'text-gray-600'}`} />
            </div>
            {isRunning && (
              <div className="absolute -top-1 -right-1 flex items-center gap-1 bg-green-500/20 border border-green-500/30 rounded-full px-2 py-0.5">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping" />
                <span className="text-[10px] text-green-400 font-semibold">{t('mining_machine_status')}</span>
              </div>
            )}
            {!isRunning && (
              <div className="absolute -top-1 -right-1 flex items-center gap-1 bg-gray-600/20 border border-gray-600/30 rounded-full px-2 py-0.5">
                <Power className="w-2.5 h-2.5 text-gray-500" />
                <span className="text-[10px] text-gray-500 font-semibold">{t('mining_machine_idle')}</span>
              </div>
            )}
          </div>

          {/* Machine info */}
          <div className="flex-1 w-full grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* Hash rate */}
            <div className="glass-light rounded-xl p-3 text-center">
              <Zap className="w-4 h-4 text-amber-400 mx-auto mb-1" />
              <div className="text-sm font-bold text-amber-400">{isRunning ? formatHashrate(totalDaily) : '0 TH/s'}</div>
              <div className="text-[10px] text-gray-500 mt-0.5">{t('mining_hashrate')}</div>
            </div>

            {/* Live earnings */}
            <div className="glass-light rounded-xl p-3 text-center">
              <Activity className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
              <div className="text-sm font-bold text-cyan-400 tabular-nums">
                +${liveEarnings.toFixed(6)}
              </div>
              <div className="text-[10px] text-gray-500 mt-0.5">{t('mining_live_earning')}{t('mining_per_second')}</div>
            </div>

            {/* Total earned live */}
            <div className="glass-light rounded-xl p-3 text-center">
              <Coins className="w-4 h-4 text-gold-400 mx-auto mb-1" />
              <div className="text-sm font-bold text-gold-400 tabular-nums">
                ${(num(totalEarned) + liveEarnings).toFixed(4)}
              </div>
              <div className="text-[10px] text-gray-500 mt-0.5">{t('mining_total_earned_live')}</div>
            </div>

            {/* Uptime */}
            <div className="glass-light rounded-xl p-3 text-center">
              <Flame className="w-4 h-4 text-orange-400 mx-auto mb-1" />
              <div className="text-sm font-bold text-orange-400 tabular-nums">{formatUptime(uptime)}</div>
              <div className="text-[10px] text-gray-500 mt-0.5">{t('mining_uptime')}</div>
            </div>
          </div>
        </div>

        {/* Progress bar showing daily earning progress */}
        {isRunning && (
          <div className="relative mt-4">
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-[11px] text-gray-400">{t('mining_daily_profit')}: ${totalDaily.toFixed(2)} USDT</span>
              <span className="text-[11px] text-cyan-400 font-semibold flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse" />
                {activeMining.length} {t('mining_active_plans')}
              </span>
            </div>
            <div className="h-1.5 glass-light rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-1000"
                style={{ width: `${Math.min((liveEarnings / (totalDaily || 1)) * 100, 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-4 text-center">
          <Coins className="w-6 h-6 text-gold-400 mx-auto mb-2" />
          <div className="text-xl font-bold text-gold-400">{activeMining.length}</div>
          <div className="text-xs text-gray-400">{t('mining_active_plans')}</div>
        </div>
        <div className="glass rounded-2xl p-4 text-center">
          <TrendingUp className="w-6 h-6 text-primary-400 mx-auto mb-2" />
          <div className="text-xl font-bold text-primary-400">${totalDaily}</div>
          <div className="text-xs text-gray-400">{t('mining_daily_profit')}</div>
        </div>
        <div className="glass rounded-2xl p-4 text-center">
          <Check className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <div className="text-xl font-bold text-green-400">${totalEarned.toFixed(2)}</div>
          <div className="text-xs text-gray-400">{t('mining_total_collected')}</div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {miningPlans.map((plan) => {
          const isActive = activeMining.some(m => m.plan_code === plan.code);
          return (
            <div
              key={plan.code}
              className={`glass rounded-2xl p-5 hover:scale-[1.04] transition-all relative overflow-hidden ${
                isActive ? 'border-gold-500/30 glow-gold' : ''
              }`}
            >
              {isActive && (
                <div className="absolute top-2 left-2 text-xs bg-gold-500/20 text-gold-400 px-2 py-0.5 rounded-full">
                  {t('status_active')}
                </div>
              )}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-3`}>
                <Flame className="w-6 h-6 text-white" />
              </div>
              <div className="font-bold text-lg mb-1">{plan.fire} {plan.code}</div>
              <div className="text-xs text-gray-400 mb-1">{t('mining_invest')}</div>
              <div className="text-lg font-bold text-white mb-2">{plan.invest === 0 ? t('mining_free') : `$${plan.invest}`}</div>
              <div className="text-xs text-gray-400 mb-1">{t('mining_daily_profit')}</div>
              <div className="text-lg font-bold text-primary-400 mb-4">${plan.daily}</div>
              <button
                onClick={() => handleSubscribe(plan)}
                disabled={actionLoading || isActive}
                className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  isActive
                    ? 'glass-light text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:scale-105'
                }`}
              >
                {isActive ? t('mining_subscribed') : plan.invest === 0 ? t('mining_activate_free') : t('mining_subscribe')}
              </button>
            </div>
          );
        })}
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">{t('mining_my_plans')}</h3>
        {loading ? (
          <div className="flex justify-center py-6"><Loader2 className="w-6 h-6 text-primary-400 animate-spin" /></div>
        ) : mining.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-6">{t('mining_no_plans')}</p>
        ) : (
          <div className="space-y-3">
            {mining.map((inv) => {
              const now = new Date();
              const hoursSinceClaim = (now.getTime() - new Date(inv.last_claim).getTime()) / (1000 * 60 * 60);
              const canClaim = hoursSinceClaim >= 24;
              const plan = miningPlans.find(p => p.code === inv.plan_code);
              return (
                <div key={inv.id} className="flex items-center justify-between p-4 glass-light rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${plan?.color ?? 'from-gray-500 to-gray-700'} flex items-center justify-center`}>
                      <Flame className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">{inv.plan_code}</div>
                      <div className="text-xs text-gray-500">
                        {t('mining_collected')}: ${num(inv.total_earned).toFixed(2)} | {t('mining_last_claim')}: {formatDate(inv.last_claim)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-sm font-bold text-primary-400">+${num(inv.daily_earn)}/{t('mining_day')}</div>
                    </div>
                    {inv.status === 'active' && (
                      <button
                        onClick={() => handleClaim(inv)}
                        disabled={actionLoading || !canClaim}
                        className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                          canClaim
                            ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900 hover:scale-105'
                            : 'glass-light text-gray-500 cursor-not-allowed'
                        }`}
                      >
                        {canClaim ? t('mining_claim') : t('mining_waiting')}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
