import { useEffect, useState } from 'react';
import { Menu, X, Flame } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';
import LanguageSelector from './LanguageSelector';

type Props = {
  onGetStarted: () => void;
  onSignIn: () => void;
};

export default function Navbar({ onGetStarted, onSignIn }: Props) {
  const { t } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  const navLinks = [
    { label: t('nav_home'), href: '#home' },
    { label: t('nav_plans'), href: '#plans' },
    { label: t('nav_features'), href: '#features' },
    { label: t('nav_how'), href: '#how' },
    { label: t('nav_testimonials'), href: '#testimonials' },
    { label: t('nav_faq'), href: '#faq' },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? 'glass py-3 shadow-lg shadow-cyan-950/20' : 'bg-transparent py-5'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center glow-primary group-hover:scale-110 transition-transform duration-300">
            <Flame className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">
            <span className="text-white">SNB</span>
            <span className="text-gradient-cyan"> Invest Mining</span>
          </span>
        </a>

        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-all duration-200"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <LanguageSelector />
          <button
            onClick={onSignIn}
            className="px-5 py-2.5 text-sm font-semibold text-gray-200 hover:text-white transition-colors"
          >
            {t('nav_signin')}
          </button>
          <button
            onClick={onGetStarted}
            className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-105"
          >
            {t('nav_start_mining')}
          </button>
        </div>

        <div className="lg:hidden flex items-center gap-2">
          <LanguageSelector />
          <button
            className="text-white p-2"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="lg:hidden glass border-t border-white/10 mt-3 animate-fade-in">
          <div className="px-6 py-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="px-4 py-3 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-all"
              >
                {link.label}
              </a>
            ))}
            <div className="flex gap-3 mt-2">
              <button
                onClick={() => { setOpen(false); onSignIn(); }}
                className="flex-1 text-center px-5 py-3 rounded-xl text-sm font-semibold text-gray-200 border border-white/10"
              >
                {t('nav_signin')}
              </button>
              <button
                onClick={() => { setOpen(false); onGetStarted(); }}
                className="flex-1 text-center px-5 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white"
              >
                {t('nav_start_mining')}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
