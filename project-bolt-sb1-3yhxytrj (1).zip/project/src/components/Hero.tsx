import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Flame, Shield, Zap, Coins, TrendingUp } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

function useCountUp(target: number, duration = 2000, start = false) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    let frame: number;
    const step = (ts: number) => {
      if (startTime === null) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(target * eased);
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [target, duration, start]);
  return value;
}

function HeroStat({ value, suffix, label, decimals = 0 }: { value: number; suffix: string; label: string; decimals?: number }) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => e.isIntersecting && setVisible(true),
      { threshold: 0.3 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  const animated = useCountUp(value, 2000, visible);
  return (
    <div ref={ref} className="glass-light rounded-2xl p-5 text-center">
      <div className="text-2xl md:text-3xl font-bold text-gradient-cyan">
        {animated.toFixed(decimals)}{suffix}
      </div>
      <div className="text-xs md:text-sm text-gray-400 mt-1">{label}</div>
    </div>
  );
}

export default function Hero() {
  const { t, dir } = useLang();

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-28 pb-16 overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-40" />
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary-600/20 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-accent-600/15 rounded-full blur-3xl animate-pulse-slow" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-6">
            <Zap className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-300">{t('hero_badge')}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight">
            {t('hero_title_1')}
            <br />
            <span className="text-gradient-cyan">{t('hero_title_2')}</span>
            <br />
            {t('hero_title_3')}
          </h1>

          <p className="mt-6 text-base sm:text-lg text-gray-400 leading-relaxed max-w-xl">
            {t('hero_desc')}
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4">
            <a
              href="#plans"
              className="group inline-flex items-center gap-2 px-7 py-4 rounded-2xl font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-105"
            >
              {t('hero_cta_1')}
              <ArrowLeft className={`w-5 h-5 group-hover:-translate-x-1 transition-transform ${dir === 'ltr' ? 'rotate-180' : ''}`} />
            </a>
            <a
              href="#how"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-2xl font-semibold glass-light text-gray-200 hover:bg-white/10 transition-all duration-300"
            >
              {t('hero_cta_2')}
            </a>
          </div>

          <div className="mt-8 flex flex-wrap gap-4 sm:gap-6">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary-400" />
              <span className="text-sm text-gray-400">{t('hero_secure')}</span>
            </div>
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-gold-500" />
              <span className="text-sm text-gray-400">{t('hero_daily')}</span>
            </div>
          </div>
        </div>

        <div className="relative animate-scale-in mt-8 lg:mt-0">
          <div className="glass rounded-3xl p-5 sm:p-8 glow-primary">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-sm text-gray-400">{t('hero_today_earn')}</div>
                <div className="text-3xl font-bold text-gradient-cyan">$ 7,112</div>
              </div>
              <div className="flex items-center gap-1 text-primary-400 bg-primary-500/10 rounded-lg px-3 py-1.5">
                <TrendingUp className="w-4 h-4" />
                <span className="text-sm font-semibold">SNB-9</span>
              </div>
            </div>

            <div className="h-48 flex items-end gap-2 mb-6">
              {[40, 55, 35, 70, 50, 80, 60, 90, 75, 95, 85, 100].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 bg-gradient-to-t from-primary-600/40 to-primary-400 rounded-t-md transition-all hover:from-primary-500/60 hover:to-primary-300"
                  style={{ height: `${h}%`, animation: `fadeUp 0.8s ease-out ${i * 0.08}s both` }}
                />
              ))}
            </div>

            <div className="grid grid-cols-3 gap-3">
              <HeroStat value={99.9} suffix="%" label={t('hero_security')} decimals={1} />
              <HeroStat value={50} suffix="K+" label={t('hero_miners')} />
              <HeroStat value={1.6} suffix="+" label={t('hero_free_daily')} decimals={1} />
            </div>
          </div>

          <div className="absolute -top-6 -left-6 glass rounded-2xl p-4 animate-float hidden md:block">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary-500/20 flex items-center justify-center">
                <Coins className="w-5 h-5 text-primary-400" />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">{t('hero_free_plan')}</div>
                <div className="text-xs text-primary-400">SNB-0 | 1.6 USDT/{t('nav_home')}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
