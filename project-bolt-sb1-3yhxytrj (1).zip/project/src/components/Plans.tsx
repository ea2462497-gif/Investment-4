import { Flame } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

const plans = [
  { code: 'SNB-0', invest: 0, daily: 1.6, color: 'from-gray-500 to-gray-700', popular: false },
  { code: 'SNB-1', invest: 13, daily: 7, color: 'from-green-500 to-green-700', popular: false },
  { code: 'SNB-2', invest: 49, daily: 28, color: 'from-teal-500 to-teal-700', popular: false },
  { code: 'SNB-3', invest: 155, daily: 99, color: 'from-cyan-500 to-cyan-700', popular: true },
  { code: 'SNB-4', invest: 372, daily: 252, color: 'from-blue-500 to-blue-700', popular: false },
  { code: 'SNB-5', invest: 720, daily: 518, color: 'from-amber-500 to-amber-700', popular: false },
  { code: 'SNB-6', invest: 1351, daily: 986, color: 'from-orange-500 to-orange-700', popular: false },
  { code: 'SNB-7', invest: 2783, daily: 2059, color: 'from-red-500 to-red-700', popular: false },
  { code: 'SNB-8', invest: 5162, daily: 3871, color: 'from-pink-500 to-pink-700', popular: false },
  { code: 'SNB-9', invest: 9358, daily: 7112, color: 'from-gold-500 to-gold-600', popular: false },
];

export default function Plans() {
  const { t } = useLang();

  return (
    <section id="plans" className="py-16 sm:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-4">
            <Flame className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-300">{t('plans_badge')}</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold">
            {t('plans_title_1')} <span className="text-gradient-cyan">{t('plans_title_2')}</span> {t('plans_title_3')}
          </h2>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t('plans_desc')}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {plans.map((plan) => (
            <div
              key={plan.code}
              className={`relative glass rounded-2xl p-5 transition-all duration-500 hover:scale-[1.04] card-hover ${
                plan.popular ? 'border-primary-500/40 glow-primary' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary-500 to-primary-600 text-white text-xs font-bold px-4 py-1.5 rounded-full whitespace-nowrap">
                  {t('plans_popular')}
                </div>
              )}

              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-3`}>
                <Flame className="w-6 h-6 text-white" />
              </div>

              <div className="font-bold text-lg mb-1">{plan.code}</div>
              <div className="text-xs text-gray-400 mb-1">{t('plans_invest')}</div>
              <div className="text-lg font-bold text-white mb-2">
                {plan.invest === 0 ? t('plans_free') : `$${plan.invest.toLocaleString()}`}
              </div>
              <div className="text-xs text-gray-400 mb-1">{t('plans_daily')}</div>
              <div className="text-lg font-bold text-primary-400 mb-4">${plan.daily.toLocaleString()}</div>

              <div className="text-xs text-gray-500 mb-3">
                {t('plans_monthly')}: <span className="text-primary-400 font-semibold">${(plan.daily * 30).toLocaleString()}</span>
              </div>

              <a
                href="#contact"
                className={`block text-center py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:scale-105'
                    : 'glass-light text-white hover:bg-white/10'
                }`}
              >
                {plan.invest === 0 ? t('plans_activate_free') : t('plans_subscribe')}
              </a>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-gray-500 mt-8">
          * {t('plans_note')}
        </p>
      </div>
    </section>
  );
}
