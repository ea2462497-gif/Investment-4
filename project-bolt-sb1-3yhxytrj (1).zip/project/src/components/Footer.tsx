import { Flame, Mail, Phone, MapPin, Twitter, Send, Facebook } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

type Props = {
  onNavigate?: (page: 'about' | 'terms' | 'privacy') => void;
};

export default function Footer({ onNavigate }: Props) {
  const { t } = useLang();

  return (
    <>
      <section id="contact" className="py-16 sm:py-24 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-primary-600/10 rounded-full blur-3xl" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="glass rounded-3xl p-7 sm:p-10 md:p-14 text-center glow-primary">
            <h2 className="text-3xl md:text-5xl font-extrabold mb-4">
              {t('cta_title_1')} <span className="text-gradient-cyan">{t('cta_title_2')}</span>?
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto mb-8">
              {t('cta_desc')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#plans"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-105"
              >
                <Flame className="w-5 h-5" />
                {t('cta_btn')}
              </a>
              <a
                href="tel:+966500000000"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl font-semibold glass-light text-gray-200 hover:bg-white/10 transition-all duration-300"
              >
                <Phone className="w-5 h-5" />
                {t('cta_contact')}
              </a>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 pt-12 sm:pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 mb-10 sm:mb-12">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center glow-primary">
                  <Flame className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">
                  <span className="text-white">SNB</span>
                  <span className="text-gradient-cyan"> Invest Mining</span>
                </span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                {t('footer_tagline')}
              </p>
              <div className="flex gap-3 mt-5">
                <a
                  href="https://t.me/Cfxbl"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl glass-light flex items-center justify-center text-gray-400 hover:text-primary-400 hover:bg-white/10 transition-all"
                  title="Telegram"
                >
                  <Send className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="w-10 h-10 rounded-xl glass-light flex items-center justify-center text-gray-400 hover:text-primary-400 hover:bg-white/10 transition-all"
                  title="Twitter"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="w-10 h-10 rounded-xl glass-light flex items-center justify-center text-gray-400 hover:text-primary-400 hover:bg-white/10 transition-all"
                  title="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">{t('footer_platform')}</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#plans" className="hover:text-white transition-colors">{t('nav_plans')}</a></li>
                <li><a href="#features" className="hover:text-white transition-colors">{t('nav_features')}</a></li>
                <li><a href="#how" className="hover:text-white transition-colors">{t('nav_how')}</a></li>
                <li><a href="#testimonials" className="hover:text-white transition-colors">{t('nav_testimonials')}</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">{t('footer_company')}</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><button onClick={() => onNavigate?.('about')} className="hover:text-white transition-colors text-left">{t('footer_about')}</button></li>
                <li><a href="#" className="hover:text-white transition-colors">{t('footer_team')}</a></li>
                <li><button onClick={() => onNavigate?.('terms')} className="hover:text-white transition-colors text-left">{t('footer_terms')}</button></li>
                <li><button onClick={() => onNavigate?.('privacy')} className="hover:text-white transition-colors text-left">{t('footer_privacy')}</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">{t('footer_contact')}</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-primary-400 flex-shrink-0" />
                  <span>support@snbinvestmining.com</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-primary-400 flex-shrink-0" />
                  <span dir="ltr">+966 50 000 0000</span>
                </li>
                <li className="flex items-center gap-3">
                  <Send className="w-5 h-5 text-primary-400 flex-shrink-0" />
                  <a href="https://t.me/Cfxbl" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors" dir="ltr">@Cfxbl</a>
                </li>
                <li className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-primary-400 flex-shrink-0" />
                  <span>Riyadh, Saudi Arabia</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-500">
              {t('footer_rights')}
            </p>
            <p className="text-xs text-gray-500">
              {t('footer_risk')}
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
