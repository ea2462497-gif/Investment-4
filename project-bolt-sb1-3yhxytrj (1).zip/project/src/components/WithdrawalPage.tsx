import { useState, useEffect, useCallback } from 'react';
import { ArrowUpRight, Wallet, Loader2, RefreshCw, Check, AlertTriangle, Coins } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LanguageContext';
import { supabase, num, type Withdrawal } from '@/lib/supabase';

const withdrawCurrencies = [
  { code: 'USDT', network: 'TRC20', color: 'text-green-400' },
  { code: 'USDT', network: 'BEP20', color: 'text-green-400' },
  { code: 'USDC', network: 'TRC20', color: 'text-blue-400' },
  { code: 'USDC', network: 'BEP20', color: 'text-blue-400' },
  { code: 'TRX', network: 'TRC20', color: 'text-red-400' },
  { code: 'BTC', network: 'Bitcoin', color: 'text-orange-400' },
  { code: 'ETH', network: 'ERC20', color: 'text-purple-400' },
];

export default function WithdrawalPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { t, lang } = useLang();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [currency, setCurrency] = useState(withdrawCurrencies[0]);
  const [amount, setAmount] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const fetchWithdrawals = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('withdrawals')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setWithdrawals((data as Withdrawal[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchWithdrawals(); }, [fetchWithdrawals]);

  const balance = num(profile?.balance);
  const numAmount = parseFloat(amount) || 0;
  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';

  const handleSubmit = async () => {
    setError(null);
    setSuccess(false);

    if (numAmount <= 0) {
      setError(lang === 'ar' ? 'الرجاء إدخال مبلغ صحيح' : 'Please enter a valid amount');
      return;
    }
    if (numAmount > balance) {
      setError(lang === 'ar' ? `رصيدك غير كافٍ. رصيدك المتاح: $${balance.toFixed(2)}` : `Insufficient balance. Available: $${balance.toFixed(2)}`);
      return;
    }
    if (numAmount < 5) {
      setError(t('wd_min'));
      return;
    }
    if (!walletAddress.trim() || walletAddress.trim().length < 10) {
      setError(lang === 'ar' ? 'الرجاء إدخال عنوان محفظة صحيح' : 'Please enter a valid wallet address');
      return;
    }

    setSubmitting(true);

    const { error: insertError } = await supabase.from('withdrawals').insert({
      user_id: user!.id,
      currency: currency.code,
      amount: numAmount,
      wallet_address: walletAddress.trim(),
      status: 'pending',
    });

    if (insertError) {
      setError(insertError.message);
      setSubmitting(false);
      return;
    }

    const { error: updateError } = await supabase
      .from('profiles')
      .update({ balance: balance - numAmount })
      .eq('id', user!.id);

    if (updateError) {
      setError(lang === 'ar' ? 'تم إنشاء طلب السحب ولكن حدث خطأ في خصم الرصيد. تواصل مع الدعم.' : 'Withdrawal created but balance deduction failed. Contact support.');
      setSubmitting(false);
      return;
    }

    await supabase.from('transactions').insert({
      user_id: user!.id,
      type: 'withdrawal',
      amount: numAmount,
      status: 'pending',
      description: `${t('wd_title')} ${currency.code}`,
    });

    setSuccess(true);
    setSubmitting(false);
    setAmount('');
    setWalletAddress('');
    fetchWithdrawals();
    refreshProfile();

    setTimeout(() => setSuccess(false), 3000);
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString(locale, {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  });

  const statusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      completed: 'bg-primary-500/10 text-primary-400 border-primary-500/20',
      rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
    };
    return (
      <span className={`text-xs px-2.5 py-1 rounded-full border ${styles[status] ?? styles.pending}`}>
        {t(`status_${status}`)}
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-2">
        <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-3">
          <ArrowUpRight className="w-4 h-4 text-primary-400" />
          <span className="text-sm text-gray-300">{t('wd_title')}</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-extrabold">
          {t('wd_title_2')}
        </h2>
        <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">
          {t('wd_desc')}
        </p>
      </div>

      <div className="glass rounded-2xl p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500/20 to-accent-500/20 flex items-center justify-center">
            <Wallet className="w-6 h-6 text-primary-400" />
          </div>
          <div>
            <div className="text-xs text-gray-400">{t('wd_balance')}</div>
            <div className="text-2xl font-bold text-gradient-cyan">${balance.toFixed(2)}</div>
          </div>
        </div>
        <button
          onClick={() => { setAmount(String(balance.toFixed(2))); }}
          className="text-xs text-primary-400 hover:text-primary-300 font-semibold px-3 py-2 rounded-lg glass-light hover:bg-white/10 transition-all"
        >
          {t('wd_withdraw_all')}
        </button>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-5">{t('wd_new')}</h3>

        <div className="mb-5">
          <label className="text-sm text-gray-400 mb-3 block">{t('wd_select_currency')}</label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {withdrawCurrencies.map((c, idx) => (
              <button
                key={`${c.code}-${c.network}-${idx}`}
                onClick={() => setCurrency(c)}
                className={`flex flex-col items-center gap-1 py-3 rounded-xl border transition-all ${
                  currency.code === c.code && currency.network === c.network
                    ? 'border-primary-500/50 bg-primary-500/10'
                    : 'border-white/5 glass-light hover:bg-white/5'
                }`}
              >
                <Coins className={`w-5 h-5 ${c.color}`} />
                <span className="text-xs font-semibold">{c.code}</span>
                <span className="text-[10px] text-gray-500">{c.network}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-4">
          <label className="text-sm text-gray-400 mb-2 block">{t('wd_amount')} (USD)</label>
          <input
            type="number"
            step="any"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            dir="ltr"
            className="w-full glass-light rounded-xl py-3.5 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right"
          />
          <p className="text-xs text-gray-500 mt-1.5">{t('wd_min')}</p>
        </div>

        <div className="mb-5">
          <label className="text-sm text-gray-400 mb-2 block">{t('wd_wallet')} {currency.code} ({currency.network})</label>
          <input
            type="text"
            placeholder={t('wd_wallet_ph') + ' ' + currency.code}
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            dir="ltr"
            className="w-full glass-light rounded-xl py-3.5 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right font-mono"
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-4 animate-fade-in">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-sm text-red-300">{error}</p>
          </div>
        )}

        {success && (
          <div className="flex items-center gap-2 bg-primary-500/10 border border-primary-500/20 rounded-xl p-3 mb-4 animate-fade-in">
            <Check className="w-4 h-4 text-primary-400 flex-shrink-0" />
            <p className="text-sm text-primary-300">{t('wd_success')}</p>
          </div>
        )}

        <div className="flex items-start gap-2 bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 mb-4">
          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-300/80">
            {t('wd_warning')} {currency.network}
          </p>
        </div>

        <button
          onClick={handleSubmit}
          disabled={submitting || balance <= 0}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-[1.02] disabled:opacity-60"
        >
          {submitting ? (
            <RefreshCw className="w-5 h-5 animate-spin" />
          ) : (
            <>
              <ArrowUpRight className="w-5 h-5" />
              {t('wd_confirm')}
            </>
          )}
        </button>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">{t('wd_history')}</h3>
          <button onClick={fetchWithdrawals} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
            <RefreshCw className="w-4 h-4" />
            {t('wd_refresh')}
          </button>
        </div>
        {loading ? (
          <div className="flex justify-center py-6"><Loader2 className="w-6 h-6 text-primary-400 animate-spin" /></div>
        ) : withdrawals.length === 0 ? (
          <div className="text-center py-8">
            <ArrowUpRight className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-sm text-gray-400">{t('wd_no_withdrawals')}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {withdrawals.map((w) => (
              <div key={w.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                    <ArrowUpRight className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">{w.currency} — ${num(w.amount).toFixed(2)}</div>
                    <div className="text-xs text-gray-500 font-mono" dir="ltr">
                      {w.wallet_address.slice(0, 8)}...{w.wallet_address.slice(-6)}
                    </div>
                    <div className="text-xs text-gray-500">{formatDate(w.created_at)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-red-400">-${num(w.amount).toFixed(2)}</span>
                  {statusBadge(w.status)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
