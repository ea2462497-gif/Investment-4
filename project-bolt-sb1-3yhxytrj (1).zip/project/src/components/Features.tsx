import { Shield, Zap, Wallet, Globe2, Clock, Flame } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

export default function Features() {
  const { t } = useLang();

  const features = [
    { icon: Flame, title: t('feat_1_t'), desc: t('feat_1_d'), color: 'from-primary-500/20 to-primary-700/20', iconColor: 'text-primary-400' },
    { icon: Zap, title: t('feat_2_t'), desc: t('feat_2_d'), color: 'from-gold-500/20 to-gold-600/20', iconColor: 'text-gold-500' },
    { icon: Shield, title: t('feat_3_t'), desc: t('feat_3_d'), color: 'from-accent-500/20 to-accent-700/20', iconColor: 'text-accent-400' },
    { icon: Wallet, title: t('feat_4_t'), desc: t('feat_4_d'), color: 'from-primary-500/20 to-primary-700/20', iconColor: 'text-primary-400' },
    { icon: Globe2, title: t('feat_5_t'), desc: t('feat_5_d'), color: 'from-gold-500/20 to-gold-600/20', iconColor: 'text-gold-500' },
    { icon: Clock, title: t('feat_6_t'), desc: t('feat_6_d'), color: 'from-accent-500/20 to-accent-700/20', iconColor: 'text-accent-400' },
  ];

  return (
    <section id="features" className="py-16 sm:py-24 relative">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-4">
            <Shield className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-300">{t('feat_badge')}</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold">
            {t('feat_title_1')} <span className="text-gradient-cyan">{t('feat_title_2')}</span>
          </h2>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t('feat_desc')}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="glass rounded-2xl p-5 sm:p-7 hover:bg-white/8 transition-all duration-300 hover:scale-[1.03] group"
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
                <f.icon className={`w-7 h-7 ${f.iconColor}`} />
              </div>
              <h3 className="text-xl font-bold mb-3">{f.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
