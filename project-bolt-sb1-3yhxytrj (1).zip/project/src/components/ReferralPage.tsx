import { useState, useEffect, useCallback } from 'react';
import { Copy, Check, Users, Gift, Share2, Link2, TrendingUp, Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LanguageContext';
import { supabase, num, type Referral } from '@/lib/supabase';

export default function ReferralPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { t, lang } = useLang();
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [directCode, setDirectCode] = useState('');

  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';

  const fetchReferrals = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('referrals')
      .select('*')
      .eq('referrer_id', user.id)
      .order('created_at', { ascending: false });
    setReferrals((data as Referral[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) return;
    fetchReferrals();
    if (!profile?.referral_code) {
      supabase
        .from('profiles')
        .select('referral_code')
        .eq('id', user.id)
        .maybeSingle()
        .then(({ data }) => {
          if (data?.referral_code) setDirectCode(data.referral_code);
        });
    }
  }, [user, profile, fetchReferrals]);

  const effectiveCode = profile?.referral_code || directCode || '';
  const siteUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const referralLink = `${siteUrl}/?ref=${effectiveCode}`;

  const copyCode = () => {
    navigator.clipboard.writeText(effectiveCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const shareText = lang === 'ar'
    ? `انضم إلى منصة SNB Invest Mining للتعدين السحابي واربح USDT يومياً! استخدم كود الدعوة الخاص بي: ${effectiveCode}`
    : `Join SNB Invest Mining cloud mining platform and earn USDT daily! Use my referral code: ${effectiveCode}`;
  const shareUrl = encodeURIComponent(referralLink);
  const shareTextEnc = encodeURIComponent(shareText);

  const shareLinks = [
    { name: 'WhatsApp', url: `https://wa.me/?text=${shareTextEnc}%20${shareUrl}`, color: 'bg-green-500/20 text-green-400' },
    { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${shareTextEnc}&url=${shareUrl}`, color: 'bg-blue-500/20 text-blue-400' },
    { name: 'Telegram', url: `https://t.me/share/url?url=${shareUrl}&text=${shareTextEnc}`, color: 'bg-cyan-500/20 text-cyan-400' },
  ];

  const completedReferrals = referrals.filter(r => r.status === 'completed').length;
  const totalReward = referrals.reduce((s, r) => s + (r.status === 'completed' ? num(r.reward) : 0), 0);

  const formatDate = (d: string) => new Date(d).toLocaleDateString(locale, { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-2">
        <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-3">
          <Gift className="w-4 h-4 text-gold-400" />
          <span className="text-sm text-gray-300">{t('ref_badge')}</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-extrabold">{t('ref_title_1')}<span className="text-gradient-cyan">{t('ref_title_2')}</span></h2>
        <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">{t('ref_desc')}</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-5 text-center">
          <Users className="w-6 h-6 text-primary-400 mx-auto mb-2" />
          <div className="text-2xl font-bold">{referrals.length}</div>
          <div className="text-xs text-gray-400">{t('ref_total')}</div>
        </div>
        <div className="glass rounded-2xl p-5 text-center">
          <Check className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold">{completedReferrals}</div>
          <div className="text-xs text-gray-400">{t('ref_completed')}</div>
        </div>
        <div className="glass rounded-2xl p-5 text-center">
          <TrendingUp className="w-6 h-6 text-gold-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gold-400">${totalReward}</div>
          <div className="text-xs text-gray-400">{t('ref_rewards')}</div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">{t('ref_code')}</h3>
        <div className="glass-light rounded-xl p-4 flex items-center gap-3 mb-4">
          <code className="flex-1 text-xl font-bold text-gold-400 font-mono text-center" dir="ltr">{effectiveCode || '—'}</code>
          <button
            onClick={copyCode}
            className="flex-shrink-0 w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            {copied ? <Check className="w-5 h-5 text-primary-400" /> : <Copy className="w-5 h-5 text-gray-400" />}
          </button>
        </div>

        <label className="text-sm text-gray-400 mb-2 block">{t('ref_link')}</label>
        <div className="glass-light rounded-xl p-4 flex items-center gap-3 mb-5">
          <Link2 className="w-5 h-5 text-gray-500 flex-shrink-0" />
          <code className="flex-1 text-sm text-gray-300 truncate" dir="ltr">{referralLink}</code>
          <button
            onClick={copyLink}
            className="flex-shrink-0 w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            {copiedLink ? <Check className="w-5 h-5 text-primary-400" /> : <Copy className="w-5 h-5 text-gray-400" />}
          </button>
        </div>

        <div className="flex gap-2">
          {shareLinks.map((s) => (
            <a
              key={s.name}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold ${s.color} hover:scale-105 transition-transform`}
            >
              <Share2 className="w-4 h-4" />
              {s.name}
            </a>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">{t('ref_list')}</h3>
        {loading ? (
          <div className="flex justify-center py-6"><Loader2 className="w-6 h-6 text-primary-400 animate-spin" /></div>
        ) : referrals.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-sm text-gray-400">{t('ref_no_referrals')}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {referrals.map((r, i) => (
              <div key={r.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-500 to-gold-500 flex items-center justify-center text-sm font-bold">
                    {i + 1}
                  </div>
                  <div>
                    <div className="text-sm font-medium">{t('ref_invite')} #{i + 1}</div>
                    <div className="text-xs text-gray-500">{formatDate(r.created_at)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-gold-400">+${num(r.reward)}</span>
                  <span className={`text-xs px-2.5 py-1 rounded-full border ${
                    r.status === 'completed'
                      ? 'bg-primary-500/10 text-primary-400 border-primary-500/20'
                      : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                  }`}>
                    {r.status === 'completed' ? t('ref_completed_badge') : t('ref_pending_badge')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
