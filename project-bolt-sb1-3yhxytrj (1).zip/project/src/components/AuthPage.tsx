import { useState, useEffect } from 'react';
import { Flame, Mail, Lock, User, Phone, ArrowLeft, AlertCircle, Loader2, Gift, AtSign } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LanguageContext';

type Props = {
  onBack: () => void;
};

type AuthMethod = 'email' | 'phone';

export default function AuthPage({ onBack }: Props) {
  const { signIn, signUp } = useAuth();
  const { t, dir } = useLang();
  const [mode, setMode] = useState<'signin' | 'signup'>('signup');
  const [authMethod, setAuthMethod] = useState<AuthMethod>('phone');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralCode(ref.toUpperCase());
      setMode('signup');
    }
  }, []);

  const identifier = authMethod === 'email' ? email : phone;
  const iconSide = dir === 'rtl' ? 'right-4' : 'left-4';
  const inputPadding = dir === 'rtl' ? 'pr-12 pl-4' : 'pl-12 pr-4';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    if (!identifier.trim()) {
      setError(authMethod === 'email' ? t('auth_enter_email') : t('auth_enter_phone'));
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError(t('auth_pwd_short'));
      setLoading(false);
      return;
    }

    if (mode === 'signin') {
      const { error } = await signIn(identifier.trim(), password);
      if (error) setError(error);
    } else {
      if (!fullName.trim()) {
        setError(t('auth_enter_name'));
        setLoading(false);
        return;
      }
      const { error } = await signUp(
        authMethod === 'email' ? email.trim() : '',
        password,
        fullName.trim(),
        authMethod === 'phone' ? phone.trim() : '',
        referralCode || undefined
      );
      if (error) setError(error);
      else {
        setSuccessMsg(t('auth_success'));
        setMode('signin');
      }
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-12 relative overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-primary-600/15 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/3 right-1/3 w-80 h-80 bg-accent-600/10 rounded-full blur-3xl animate-pulse-slow" />

      <div className="w-full max-w-md relative z-10">
        <a href="/" onClick={(e) => { e.preventDefault(); onBack(); }} className="flex items-center justify-center gap-3 mb-8 cursor-pointer">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center glow-primary">
            <Flame className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold">
            <span className="text-white">SNB</span>
            <span className="text-gradient-cyan"> Mining</span>
          </span>
        </a>

        <div className="glass rounded-3xl p-8 md:p-10">
          <div className="flex gap-2 p-1 glass-light rounded-xl mb-6">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                mode === 'signin' ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('auth_signin')}
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                mode === 'signup' ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white' : 'text-gray-400'
              }`}
            >
              {t('auth_signup')}
            </button>
          </div>

          {mode === 'signup' && (
            <div className="flex gap-2 p-1 glass-light rounded-xl mb-6">
              <button
                onClick={() => setAuthMethod('phone')}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  authMethod === 'phone' ? 'bg-primary-500/20 text-primary-400' : 'text-gray-400'
                }`}
              >
                <Phone className="w-3.5 h-3.5" />
                {t('auth_phone')}
              </button>
              <button
                onClick={() => setAuthMethod('email')}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  authMethod === 'email' ? 'bg-primary-500/20 text-primary-400' : 'text-gray-400'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                {t('auth_email')}
              </button>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-5 animate-fade-in">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <p className="text-sm text-red-300">{error}</p>
            </div>
          )}

          {successMsg && (
            <div className="flex items-center gap-2 bg-primary-500/10 border border-primary-500/20 rounded-xl p-3 mb-5 animate-fade-in">
              <Loader2 className="w-5 h-5 text-primary-400 flex-shrink-0" />
              <p className="text-sm text-primary-300">{successMsg}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {mode === 'signup' && (
              <>
                <div className="relative">
                  <User className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
                  <input
                    type="text"
                    placeholder={t('auth_fullname')}
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all`}
                  />
                </div>

                {authMethod === 'phone' ? (
                  <div className="relative">
                    <Phone className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
                    <input
                      type="tel"
                      placeholder={t('auth_phone_ph')}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                      dir="ltr"
                      className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right`}
                    />
                  </div>
                ) : (
                  <div className="relative">
                    <Mail className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
                    <input
                      type="email"
                      placeholder={t('auth_email_ph')}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      dir="ltr"
                      className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right`}
                    />
                  </div>
                )}

                <div className="relative">
                  <Gift className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
                  <input
                    type="text"
                    placeholder={t('auth_refcode')}
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                    dir="ltr"
                    className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500/50 transition-all text-right`}
                  />
                </div>
              </>
            )}

            {mode === 'signin' && (
              <div className="relative">
                <AtSign className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
                <input
                  type="text"
                  placeholder={t('auth_identifier')}
                  value={identifier}
                  onChange={(e) => authMethod === 'email' ? setEmail(e.target.value) : setPhone(e.target.value)}
                  required
                  dir="ltr"
                  className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right`}
                />
              </div>
            )}

            <div className="relative">
              <Lock className={`absolute ${iconSide} top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500`} />
              <input
                type="password"
                placeholder={t('auth_password')}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                dir="ltr"
                className={`w-full glass-light rounded-xl py-3.5 ${inputPadding} text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all text-right`}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-400 hover:to-primary-500 transition-all duration-300 glow-primary hover:scale-[1.02] disabled:opacity-60"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  {mode === 'signin' ? t('auth_signin_btn') : t('auth_create_btn')}
                  <ArrowLeft className={`w-5 h-5 ${dir === 'ltr' ? 'rotate-180' : ''}`} />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-xs text-gray-500 mt-6">
            {t('auth_terms')}
          </p>
        </div>

        <button
          onClick={onBack}
          className="flex items-center justify-center gap-2 mt-6 text-sm text-gray-400 hover:text-white transition-colors"
        >
          <ArrowLeft className={`w-4 h-4 ${dir === 'ltr' ? '' : 'rotate-180'}`} />
          {t('auth_back')}
        </button>
      </div>
    </div>
  );
}
