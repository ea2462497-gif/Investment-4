import { useState, useEffect, useCallback } from 'react';
import {
  TrendingUp, Wallet, ArrowUpRight, ArrowDownRight,
  Plus, PieChart, History, LogOut, BarChart3, Crown, Sparkles,
  Loader2, RefreshCw, Flame, Gift, Shield, Trophy, Target, Lock,
  Users, Check, X, DollarSign, Star, Award, Zap,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LanguageContext';
import { supabase, num, type Deposit, type Transaction, type Investment, type Withdrawal } from '@/lib/supabase';
import DepositModal from './DepositModal';
import MiningPage from './MiningPage';
import ReferralPage from './ReferralPage';
import WithdrawalPage from './WithdrawalPage';

type Tab = 'overview' | 'withdraw' | 'rewards' | 'mining' | 'referral' | 'history' | 'admin';

const planInfo: Record<string, { labelKey: string; min: number; returnRange: string; color: string }> = {
  beginner: { labelKey: 'plan_beginner', min: 500, returnRange: '8 - 12', color: 'from-primary-500 to-primary-700' },
  pro: { labelKey: 'plan_pro', min: 5000, returnRange: '12 - 18', color: 'from-gold-500 to-gold-600' },
  elite: { labelKey: 'plan_elite', min: 50000, returnRange: '18 - 25', color: 'from-accent-500 to-accent-700' },
};

const planIcons: Record<string, typeof TrendingUp> = {
  beginner: TrendingUp,
  pro: Sparkles,
  elite: Crown,
};

export default function Dashboard() {
  const { user, profile, isAdmin, signOut, refreshProfile } = useAuth();
  const { t, lang } = useLang();
  const [tab, setTab] = useState<Tab>('overview');
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [loading, setLoading] = useState(true);
  const [depositOpen, setDepositOpen] = useState(false);
  const [depositPlan, setDepositPlan] = useState('beginner');
  const [localIsAdmin, setLocalIsAdmin] = useState(false);
  const [referralsCount, setReferralsCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase
      .rpc('is_current_user_admin')
      .then(({ data, error }) => {
        if (error) {
          console.error('Admin check error:', error);
          return;
        }
        setLocalIsAdmin(data === true);
      });
    supabase
      .from('referrals')
      .select('id', { count: 'exact', head: true })
      .eq('referrer_id', user.id)
      .then(({ count }) => {
        setReferralsCount(count ?? 0);
      });

    // Realtime: auto-refresh profile when balance changes (e.g. admin updates it)
    const channel = supabase
      .channel('profiles-changes')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}` },
        () => {
          refreshProfile();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, refreshProfile]);

  const adminMode = isAdmin || localIsAdmin;

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [depRes, txRes, invRes] = await Promise.all([
        supabase.from('deposits').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('transactions').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('investments').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      ]);
      setDeposits((depRes.data as Deposit[]) ?? []);
      setTransactions((txRes.data as Transaction[]) ?? []);
      setInvestments((invRes.data as Investment[]) ?? []);
    } catch (err) {
      console.error('Dashboard fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);


  const handleDeposit = (plan: string) => {
    setDepositPlan(plan);
    setDepositOpen(true);
  };

  const handleDepositSubmitted = () => {
    fetchData();
    refreshProfile();
  };

  const handleInvest = async (plan: string) => {
    if (!user) return;
    const info = planInfo[plan];
    const minAmount = parseFloat(prompt(`${t('dash_invest_prompt')} (${info.min}):`) ?? '');
    if (!minAmount || minAmount < info.min) {
      alert(`${t('dash_invest_min')} ${info.min}`);
      return;
    }
    const expectedReturn = (minAmount * (parseFloat(info.returnRange.split(' - ')[0]) / 100));

    const { error } = await supabase.from('investments').insert({
      user_id: user.id,
      plan,
      amount: minAmount,
      expected_return: expectedReturn,
      status: 'active',
    });

    if (error) {
      alert(error.message);
      return;
    }

    alert(t('dash_invest_success'));
    fetchData();
    refreshProfile();
  };

  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(locale, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  };

  const statusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      confirmed: 'bg-primary-500/10 text-primary-400 border-primary-500/20',
      completed: 'bg-primary-500/10 text-primary-400 border-primary-500/20',
      active: 'bg-primary-500/10 text-primary-400 border-primary-500/20',
      rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
      failed: 'bg-red-500/10 text-red-400 border-red-500/20',
    };
    return (
      <span className={`text-xs px-2.5 py-1 rounded-full border ${styles[status] ?? styles.pending}`}>
        {t(`status_${status}`) !== `status_${status}` ? t(`status_${status}`) : status}
      </span>
    );
  };

  const totalDeposited = deposits.filter(d => d.status === 'confirmed').reduce((sum, d) => sum + num(d.amount), 0);
  const activeInvestments = investments.filter(i => i.status === 'active');
  const totalActive = activeInvestments.reduce((sum, i) => sum + num(i.amount), 0);

  const navItems: { key: Tab; label: string; icon: typeof PieChart }[] = [
    { key: 'overview', label: t('dash_overview'), icon: BarChart3 },
    { key: 'mining', label: t('dash_mining'), icon: Flame },
    { key: 'withdraw', label: t('dash_withdraw'), icon: ArrowUpRight },
    { key: 'rewards', label: t('dash_rewards'), icon: Trophy },
    { key: 'referral', label: t('dash_referral'), icon: Gift },
    { key: 'history', label: t('dash_history'), icon: History },
    ...(adminMode ? [{ key: 'admin' as Tab, label: t('dash_admin'), icon: Shield }] : []),
  ];

  // Admin tab renders AdminDashboard inline
  if (tab === 'admin' && adminMode) {
    return (
      <div className="min-h-screen bg-navy-950 pt-20">
        <div className="glass border-b border-white/5 sticky top-16 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-500 to-gold-600 flex items-center justify-center font-bold flex-shrink-0">
                <Shield className="w-5 h-5 text-navy-900" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold truncate">{t('dash_admin')}</div>
                <div className="text-xs text-gold-400 truncate">{profile?.full_name}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button onClick={() => setTab('overview')} className="px-3 sm:px-4 py-2 rounded-xl glass-light text-xs sm:text-sm text-gray-300 hover:text-white transition-colors whitespace-nowrap">
                {t('dash_back_user')}
              </button>
              <button onClick={signOut} className="w-10 h-10 rounded-xl glass-light flex items-center justify-center text-gray-400 hover:text-red-400 transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
        <AdminContent refreshProfile={refreshProfile} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950 pt-20">
      {/* Top bar */}
      <div className="glass border-b border-white/5 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-gold-500 flex items-center justify-center font-bold flex-shrink-0">
              {profile?.full_name?.charAt(0) ?? user?.email?.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{profile?.full_name || t('dash_user')}</div>
              <div className="text-xs text-gray-400 truncate">{user?.email}</div>
            </div>
            {adminMode && (
              <span className="text-xs bg-gold-500/20 text-gold-400 px-2 py-0.5 rounded-full hidden sm:inline">{t('dash_manager')}</span>
            )}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => handleDeposit('beginner')}
              className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:scale-105 transition-transform glow-primary whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>{t('dash_deposit_btn')}</span>
            </button>
            <button onClick={signOut} className="w-10 h-10 rounded-xl glass-light flex items-center justify-center text-gray-400 hover:text-red-400 transition-colors" title={t('dash_logout')}>
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Tabs */}
        <div className="flex gap-1 p-1 glass-light rounded-xl mb-6 sm:mb-8 overflow-x-auto scrollbar-thin">
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => setTab(item.key)}
              className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                tab === item.key ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </div>

        {/* Mining, Referral, and Withdrawal tabs render their own components */}
        {tab === 'mining' && <MiningPage />}
        {tab === 'referral' && <ReferralPage />}
        {tab === 'withdraw' && <WithdrawalPage />}

        {loading && tab !== 'mining' && tab !== 'referral' && tab !== 'withdraw' && tab !== 'rewards' ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-primary-400 animate-spin" />
          </div>
        ) : (
          <>
            {/* OVERVIEW TAB */}
            {tab === 'overview' && (
              <div className="space-y-6 animate-fade-in">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { label: t('dash_balance'), value: `${num(profile?.balance).toFixed(2)}`, icon: Wallet, color: 'from-primary-500/20 to-primary-700/20', iconColor: 'text-primary-400' },
                    { label: t('dash_total_deposit'), value: `${totalDeposited.toFixed(2)}`, icon: ArrowDownRight, color: 'from-gold-500/20 to-gold-600/20', iconColor: 'text-gold-400' },
                    { label: t('dash_total_invest'), value: `${totalActive.toFixed(2)}`, icon: TrendingUp, color: 'from-accent-500/20 to-accent-700/20', iconColor: 'text-accent-400' },
                    { label: t('dash_total_profit'), value: `${num(profile?.total_profit).toFixed(2)}`, icon: ArrowUpRight, color: 'from-primary-500/20 to-gold-500/20', iconColor: 'text-gold-400' },
                  ].map((stat) => (
                    <div key={stat.label} className="glass rounded-2xl p-4 sm:p-5 hover:bg-white/8 transition-all">
                      <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                        <stat.icon className={`w-6 h-6 ${stat.iconColor}`} />
                      </div>
                      <div className="text-xl sm:text-2xl font-bold truncate">{stat.value}</div>
                      <div className="text-xs text-gray-400 mt-1">{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* Portfolio chart placeholder */}
                <div className="glass rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold">{t('dash_portfolio')}</h3>
                    <span className="text-sm text-primary-400 flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      {t('dash_growing')}
                    </span>
                  </div>
                  <div className="h-48 flex items-end gap-2">
                    {[35, 50, 42, 65, 55, 72, 60, 85, 70, 90, 80, 100].map((h, i) => (
                      <div
                        key={i}
                        className="flex-1 bg-gradient-to-t from-primary-600/40 to-primary-400 rounded-t-md hover:from-primary-500/60 hover:to-primary-300 transition-all"
                        style={{ height: `${h}%` }}
                      />
                    ))}
                  </div>
                </div>

                {/* Plan display */}
                <div className="glass rounded-2xl p-6">
                  <h3 className="text-lg font-bold mb-4">{t('dash_current_plan')}</h3>
                  {(() => {
                    const plan = profile?.plan ?? 'beginner';
                    const info = planInfo[plan];
                    const Icon = planIcons[plan];
                    return (
                      <div className="flex items-center gap-4">
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${info.color} flex items-center justify-center`}>
                          <Icon className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <div className="text-lg sm:text-xl font-bold">{t(info.labelKey)}</div>
                          <div className="text-xs sm:text-sm text-gray-400">{t('dash_expected_return')}: {info.returnRange}%</div>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Recent transactions */}
                <div className="glass rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold">{t('dash_recent')}</h3>
                    <button onClick={() => setTab('history')} className="text-sm text-primary-400 hover:text-primary-300">
                      {t('dash_view_all')}
                    </button>
                  </div>
                  {transactions.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-6">{t('dash_no_tx')}</p>
                  ) : (
                    <div className="space-y-2">
                      {transactions.slice(0, 5).map((tx) => (
                        <div key={tx.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tx.type === 'deposit' || tx.type === 'mining_investment' ? 'bg-primary-500/10' : 'bg-gold-500/10'}`}>
                              {tx.type === 'deposit' || tx.type === 'mining_investment' ? <ArrowDownRight className="w-4 h-4 text-primary-400" /> : <ArrowUpRight className="w-4 h-4 text-gold-400" />}
                            </div>
                            <div>
                              <div className="text-sm font-medium">{tx.description || tx.type}</div>
                              <div className="text-xs text-gray-500">{formatDate(tx.created_at)}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-semibold">${num(tx.amount).toFixed(2)}</span>
                            {statusBadge(tx.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* REWARDS TAB */}
            {tab === 'rewards' && (
              <RewardsTab referralCount={referralsCount} />
            )}

            {/* HISTORY TAB */}
            {tab === 'history' && (
              <div className="space-y-6 animate-fade-in">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-2xl font-bold">{t('dash_history')}</h2>
                  <button onClick={fetchData} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
                    <RefreshCw className="w-4 h-4" />
                    {t('wd_refresh')}
                  </button>
                </div>

                <div className="glass rounded-2xl p-6">
                  {transactions.length === 0 && deposits.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-10">{t('dash_no_tx')}</p>
                  ) : (
                    <div className="space-y-2">
                      {[...transactions, ...deposits.map(d => ({
                        id: d.id,
                        user_id: d.user_id,
                        type: 'deposit',
                        amount: d.amount,
                        status: d.status,
                        description: `${t('dep_title')} ${d.currency} - ${t(planInfo[d.plan]?.labelKey ?? 'plan_beginner')}`,
                        created_at: d.created_at,
                      } as Transaction))]
                        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                        .map((tx) => (
                          <div key={tx.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tx.type === 'deposit' || tx.type === 'mining_investment' ? 'bg-primary-500/10' : tx.type === 'profit' || tx.type === 'mining_profit' ? 'bg-gold-500/10' : 'bg-red-500/10'}`}>
                                {tx.type === 'deposit' || tx.type === 'mining_investment' ? <ArrowDownRight className="w-5 h-5 text-primary-400" /> : tx.type === 'profit' || tx.type === 'mining_profit' ? <TrendingUp className="w-5 h-5 text-gold-400" /> : <ArrowUpRight className="w-5 h-5 text-red-400" />}
                              </div>
                              <div>
                                <div className="text-sm font-medium">{tx.description || tx.type}</div>
                                <div className="text-xs text-gray-500">{formatDate(tx.created_at)}</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className={`text-sm font-semibold ${tx.type === 'withdrawal' || tx.type === 'deduct' ? 'text-red-400' : 'text-white'}`}>
                                {tx.type === 'withdrawal' || tx.type === 'deduct' ? '-' : '+'}${num(tx.amount).toFixed(2)}
                              </span>
                              {statusBadge(tx.status)}
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <DepositModal
        open={depositOpen}
        onClose={() => setDepositOpen(false)}
        selectedPlan={depositPlan}
        onDepositSubmitted={handleDepositSubmitted}
      />
    </div>
  );
}

function RewardsTab({ referralCount }: { referralCount: number }) {
  const { t, lang } = useLang();
  const target = 20;
  const progress = Math.min((referralCount / target) * 100, 100);
  const unlocked = referralCount >= target;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center mb-2">
        <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-3">
          <Trophy className="w-4 h-4 text-gold-400" />
          <span className="text-sm text-gray-300">{t('rewards_title')}</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-extrabold">{t('rewards_title')}</h2>
        <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">{t('rewards_subtitle')}</p>
      </div>

      {/* Invite 20 Members Reward Card */}
      <div className="glass rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gold-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="relative z-10">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gold-500 to-gold-600 flex items-center justify-center flex-shrink-0">
              <Crown className="w-7 h-7 text-navy-900" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg sm:text-xl font-bold mb-1">{t('rewards_invite_title')}</h3>
              <p className="text-sm text-gray-400 leading-relaxed">{t('rewards_invite_desc')}</p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">{t('rewards_progress')}</span>
              <span className="text-sm font-bold text-gold-400">{referralCount} / {target}</span>
            </div>
            <div className="h-3 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-gold-500 to-gold-400 transition-all duration-500 relative"
                style={{ width: `${progress}%` }}
              >
                {progress > 0 && (
                  <div className="absolute inset-0 bg-white/20 animate-pulse" />
                )}
              </div>
            </div>
          </div>

          {/* Reward badge */}
          <div className="flex items-center justify-between gap-4 pt-4 border-t border-white/5">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${unlocked ? 'bg-green-500/20' : 'bg-white/5'}`}>
                {unlocked ? <Check className="w-5 h-5 text-green-400" /> : <Lock className="w-5 h-5 text-gray-500" />}
              </div>
              <div>
                <div className="text-sm font-semibold">
                  {unlocked ? t('rewards_unlocked') : t('rewards_locked')}
                </div>
                <div className="text-xs text-gray-500">SNB-2 + 28.00 USDT</div>
              </div>
            </div>
            <button
              disabled={!unlocked}
              className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                unlocked
                  ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900 hover:scale-105'
                  : 'glass-light text-gray-500 cursor-not-allowed'
              }`}
            >
              {unlocked ? t('rewards_claim') : `${target - referralCount} ${t('rewards_target')}`}
            </button>
          </div>
        </div>
      </div>

      {/* Cumulative Rewards Card */}
      <div className="glass rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        <div className="relative z-10">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center flex-shrink-0">
              <Award className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg sm:text-xl font-bold mb-1">{t('rewards_cumulative_title')}</h3>
              <p className="text-sm text-gray-400 leading-relaxed">{t('rewards_cumulative_desc')}</p>
            </div>
          </div>

          {/* Level milestones */}
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { level: 'SNB-3', req: lang === 'ar' ? 'عضو واحد يشحن' : '1 member recharges', icon: Zap, color: 'from-blue-500 to-blue-600' },
              { level: 'SNB-5', req: lang === 'ar' ? '3 أعضاء يشحنون' : '3 members recharge', icon: Star, color: 'from-primary-500 to-primary-600' },
              { level: 'SNB-7', req: lang === 'ar' ? '5 أعضاء يشحنون' : '5 members recharge', icon: Crown, color: 'from-gold-500 to-gold-600' },
            ].map((milestone) => (
              <div key={milestone.level} className="glass-light rounded-2xl p-4 text-center hover:scale-[1.03] transition-all">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${milestone.color} flex items-center justify-center mx-auto mb-3`}>
                  <milestone.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm font-bold mb-1">{milestone.level}</div>
                <div className="text-xs text-gray-500">{milestone.req}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-5 text-center">
          <Users className="w-6 h-6 text-primary-400 mx-auto mb-2" />
          <div className="text-2xl font-bold">{referralCount}</div>
          <div className="text-xs text-gray-400">{t('rewards_invite_count')}</div>
        </div>
        <div className="glass rounded-2xl p-5 text-center">
          <Target className="w-6 h-6 text-gold-400 mx-auto mb-2" />
          <div className="text-2xl font-bold">{target}</div>
          <div className="text-xs text-gray-400">{t('rewards_target')}</div>
        </div>
        <div className="glass rounded-2xl p-5 text-center">
          <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gold-400">28.00</div>
          <div className="text-xs text-gray-400">USDT</div>
        </div>
      </div>
    </div>
  );
}

// Inline admin content to avoid circular imports
function AdminContent({ refreshProfile }: { refreshProfile: () => Promise<void> }) {
  const { t, lang } = useLang();
  const [adminTab, setAdminTab] = useState<'deposits' | 'withdrawals' | 'users' | 'addbalance' | 'addresses'>('deposits');
  const [adminDeposits, setAdminDeposits] = useState<Deposit[]>([]);
  const [adminUsers, setAdminUsers] = useState<{ id: string; full_name: string; phone: string; balance: number; total_invested: number; total_profit: number; plan: string; is_admin: boolean; referral_code: string }[]>([]);
  const [adminAddresses, setAdminAddresses] = useState<{ id: string; currency: string; network: string; address: string; is_active: boolean }[]>([]);
  const [adminWithdrawals, setAdminWithdrawals] = useState<Withdrawal[]>([]);
  const [adminLoading, setAdminLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [addBalanceUser, setAddBalanceUser] = useState('');
  const [addBalanceAmount, setAddBalanceAmount] = useState('');
  const [addBalanceType, setAddBalanceType] = useState('deposit');
  const [searchTerm, setSearchTerm] = useState('');

  const fetchAdminData = useCallback(async () => {
    setAdminLoading(true);
    try {
      const [depRes, addrRes, wdRes] = await Promise.all([
        supabase.from('deposits').select('*').order('created_at', { ascending: false }),
        supabase.from('deposit_addresses').select('*').order('currency'),
        supabase.from('withdrawals').select('*').order('created_at', { ascending: false }),
      ]);
      if (depRes.error) console.error('Admin deposits error:', depRes.error);
      if (addrRes.error) console.error('Admin addresses error:', addrRes.error);
      if (wdRes.error) console.error('Admin withdrawals error:', wdRes.error);
      setAdminDeposits((depRes.data as Deposit[]) ?? []);
      setAdminAddresses((addrRes.data as typeof adminAddresses) ?? []);
      setAdminWithdrawals((wdRes.data as Withdrawal[]) ?? []);

      const { data: usersData, error: usersError } = await supabase.rpc('get_all_profiles_admin');
      if (usersError) {
        console.error('Admin users RPC error:', usersError);
      } else {
        setAdminUsers((usersData as typeof adminUsers) ?? []);
      }
    } catch (err) {
      console.error('Admin fetch error:', err);
    } finally {
      setAdminLoading(false);
    }
  }, []);

  useEffect(() => { fetchAdminData(); }, [fetchAdminData]);

  const confirmDeposit = async (dep: Deposit) => {
    setActionLoading(true);
    const { error: depError } = await supabase.from('deposits').update({ status: 'confirmed' }).eq('id', dep.id);
    if (depError) { console.error('Confirm deposit error:', depError); alert(depError.message); setActionLoading(false); return; }
    const u = adminUsers.find(x => x.id === dep.user_id);
    if (u) {
      const { error: balError } = await supabase.rpc('admin_update_balance', {
        p_user_id: dep.user_id,
        p_balance: num(u.balance) + num(dep.amount),
        p_total_invested: num(u.total_invested) + num(dep.amount),
      });
      if (balError) { console.error('Admin update balance error:', balError); alert(balError.message); setActionLoading(false); return; }
    }
    const { error: txError } = await supabase.from('transactions').insert({
      user_id: dep.user_id,
      type: 'deposit',
      amount: dep.amount,
      status: 'completed',
      description: `Deposit confirm ${dep.currency} - ${dep.plan}`,
    });
    if (txError) console.error('Transaction insert error:', txError);
    setActionLoading(false);
    await fetchAdminData();
    await refreshProfile();
    alert('تم تأكيد الإيداع');
  };

  const rejectDeposit = async (dep: Deposit) => {
    setActionLoading(true);
    const { error } = await supabase.from('deposits').update({ status: 'rejected' }).eq('id', dep.id);
    if (error) { console.error('Reject deposit error:', error); alert(error.message); }
    setActionLoading(false);
    fetchAdminData();
  };

  const handleAddBalance = async () => {
    const amount = parseFloat(addBalanceAmount);
    if (!addBalanceUser || !amount || amount <= 0) { alert(lang === 'ar' ? 'اختر مستخدم وأدخل مبلغ صحيح' : 'Select a user and enter a valid amount'); return; }
    setActionLoading(true);
    const u = adminUsers.find(x => x.id === addBalanceUser);
    if (!u) { alert(lang === 'ar' ? 'المستخدم غير موجود' : 'User not found'); setActionLoading(false); return; }

    let newBalance = num(u.balance);
    let newInvested = num(u.total_invested);
    let newProfit = num(u.total_profit);

    if (addBalanceType === 'deposit') {
      newBalance = num(u.balance) + amount;
      newInvested = num(u.total_invested) + amount;
    } else if (addBalanceType === 'profit') {
      newBalance = num(u.balance) + amount;
      newProfit = num(u.total_profit) + amount;
    } else {
      newBalance = Math.max(0, num(u.balance) - amount);
    }

    const { error: updateError } = await supabase.rpc('admin_update_balance', {
      p_user_id: addBalanceUser,
      p_balance: newBalance,
      p_total_invested: newInvested,
      p_total_profit: newProfit,
    });

    if (updateError) {
      alert((lang === 'ar' ? 'خطأ: ' : 'Error: ') + updateError.message);
      setActionLoading(false);
      return;
    }

    await supabase.from('transactions').insert({
      user_id: addBalanceUser,
      type: addBalanceType === 'deduct' ? 'withdrawal' : addBalanceType,
      amount: amount,
      status: 'completed',
      description: addBalanceType === 'deduct' ? (lang === 'ar' ? 'خصم يدوي' : 'Manual deduction') : `${lang === 'ar' ? 'إضافة يدوية' : 'Manual addition'} (${addBalanceType})`,
    });
    setActionLoading(false);
    setAddBalanceAmount('');
    setAddBalanceUser('');
    await fetchAdminData();
    await refreshProfile();
    alert(lang === 'ar' ? 'تم تعديل الرصيد' : 'Balance updated');
  };

  const toggleAddress = async (id: string, current: boolean) => {
    await supabase.from('deposit_addresses').update({ is_active: !current }).eq('id', id);
    fetchAdminData();
  };

  const updateAddress = async (id: string, newAddr: string) => {
    await supabase.from('deposit_addresses').update({ address: newAddr }).eq('id', id);
    fetchAdminData();
    alert(lang === 'ar' ? 'تم تحديث العنوان' : 'Address updated');
  };

  const fmtDate = (d: string) => new Date(d).toLocaleDateString(lang === 'ar' ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const pendingDeps = adminDeposits.filter(d => d.status === 'pending');
  const confirmedDeps = adminDeposits.filter(d => d.status === 'confirmed');
  const totalVol = confirmedDeps.reduce((s, d) => s + num(d.amount), 0);
  const pendingWds = adminWithdrawals.filter(w => w.status === 'pending');

  const confirmWithdrawal = async (wd: Withdrawal) => {
    setActionLoading(true);
    await supabase.from('withdrawals').update({ status: 'completed' }).eq('id', wd.id);
    await supabase.from('transactions').insert({
      user_id: wd.user_id,
      type: 'withdrawal',
      amount: wd.amount,
      status: 'completed',
      description: `${t('wd_title')} ${wd.currency} - ${t('admin_confirm')}`,
    });
    setActionLoading(false);
    await fetchAdminData();
    await refreshProfile();
    alert(lang === 'ar' ? 'تم تأكيد السحب' : 'Withdrawal confirmed');
  };

  const rejectWithdrawal = async (wd: Withdrawal) => {
    setActionLoading(true);
    await supabase.from('withdrawals').update({ status: 'rejected' }).eq('id', wd.id);
    const u = adminUsers.find(x => x.id === wd.user_id);
    if (u) {
      await supabase.rpc('admin_update_balance', {
        p_user_id: wd.user_id,
        p_balance: num(u.balance) + num(wd.amount),
      });
    }
    setActionLoading(false);
    await fetchAdminData();
    await refreshProfile();
    alert(lang === 'ar' ? 'تم رفض السحب وإرجاع الرصيد' : 'Withdrawal rejected and balance refunded');
  };
  const filteredUsers = adminUsers.filter(u => !searchTerm || u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || u.referral_code?.toLowerCase().includes(searchTerm.toLowerCase()));

  if (adminLoading) return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-gold-400 animate-spin" /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
        <div className="glass rounded-2xl p-4 sm:p-5">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-primary-500/20 flex items-center justify-center mb-3"><Users className="w-5 h-5 sm:w-6 sm:h-6 text-primary-400" /></div>
          <div className="text-xl sm:text-2xl font-bold">{adminUsers.length}</div>
          <div className="text-xs text-gray-400 mt-1">{t('admin_total_users')}</div>
        </div>
        <div className="glass rounded-2xl p-4 sm:p-5">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-500/20 flex items-center justify-center mb-3"><ArrowDownRight className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" /></div>
          <div className="text-xl sm:text-2xl font-bold">{pendingDeps.length}</div>
          <div className="text-xs text-gray-400 mt-1">{t('admin_pending')}</div>
        </div>
        <div className="glass rounded-2xl p-4 sm:p-5">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-green-500/20 flex items-center justify-center mb-3"><Check className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" /></div>
          <div className="text-xl sm:text-2xl font-bold">{confirmedDeps.length}</div>
          <div className="text-xs text-gray-400 mt-1">{t('admin_confirmed')}</div>
        </div>
        <div className="glass rounded-2xl p-4 sm:p-5">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gold-500/20 flex items-center justify-center mb-3"><DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-gold-400" /></div>
          <div className="text-xl sm:text-2xl font-bold">${totalVol.toFixed(2)}</div>
          <div className="text-xs text-gray-400 mt-1">{t('admin_volume')}</div>
        </div>
      </div>

      {/* Admin tabs */}
      <div className="flex gap-1 p-1 glass-light rounded-xl mb-6 sm:mb-8 overflow-x-auto scrollbar-thin">
        {[
          { key: 'deposits' as const, label: t('admin_deposits'), badge: pendingDeps.length },
          { key: 'withdrawals' as const, label: t('admin_withdrawals'), badge: pendingWds.length },
          { key: 'users' as const, label: t('admin_users'), badge: 0 },
          { key: 'addbalance' as const, label: t('admin_balance'), badge: 0 },
          { key: 'addresses' as const, label: t('admin_addresses'), badge: 0 },
        ].map((item) => (
          <button
            key={item.key}
            onClick={() => setAdminTab(item.key)}
            className={`flex items-center gap-2 px-3 sm:px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap relative transition-all ${
              adminTab === item.key ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900' : 'text-gray-400 hover:text-white'
            }`}
          >
            {item.label}
            {item.badge > 0 && <span className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">{item.badge}</span>}
          </button>
        ))}
      </div>

      {/* Withdrawals */}
      {adminTab === 'withdrawals' && (
        <div className="space-y-3 animate-fade-in">
          {adminWithdrawals.length === 0 ? <p className="text-sm text-gray-400 text-center py-10">{t('admin_no_withdrawals')}</p> : adminWithdrawals.map((wd) => (
            <div key={wd.id} className="glass rounded-xl p-4 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0"><ArrowUpRight className="w-5 h-5 text-red-400" /></div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{wd.amount} {wd.currency}</div>
                  <div className="text-xs text-gray-500 truncate font-mono" dir="ltr">{wd.wallet_address.slice(0, 16)}...</div>
                  <div className="text-xs text-gray-500">{fmtDate(wd.created_at)}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2.5 py-1 rounded-full border ${wd.status === 'completed' ? 'bg-primary-500/10 text-primary-400 border-primary-500/20' : wd.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                  {wd.status === 'completed' ? t('status_completed') : wd.status === 'pending' ? t('status_pending') : t('status_rejected')}
                </span>
                {wd.status === 'pending' && (
                  <>
                    <button onClick={() => confirmWithdrawal(wd)} disabled={actionLoading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-500/20 text-primary-400 hover:bg-primary-500/30"><Check className="w-3.5 h-3.5" /> {t('admin_confirm')}</button>
                    <button onClick={() => rejectWithdrawal(wd)} disabled={actionLoading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-red-500/20 text-red-400 hover:bg-red-500/30"><X className="w-3.5 h-3.5" /> {t('admin_reject')}</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Deposits */}
      {adminTab === 'deposits' && (
        <div className="space-y-3 animate-fade-in">
          {adminDeposits.length === 0 ? <p className="text-sm text-gray-400 text-center py-10">{t('admin_no_deposits')}</p> : adminDeposits.map((dep) => (
            <div key={dep.id} className="glass rounded-xl p-4 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-primary-500/10 flex items-center justify-center flex-shrink-0"><ArrowDownRight className="w-5 h-5 text-primary-400" /></div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{dep.amount} {dep.currency} — {dep.plan}</div>
                  <div className="text-xs text-gray-500 truncate">{fmtDate(dep.created_at)} | TxHash: <span dir="ltr">{dep.tx_hash?.substring(0, 20)}...</span></div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2.5 py-1 rounded-full border ${dep.status === 'confirmed' ? 'bg-primary-500/10 text-primary-400 border-primary-500/20' : dep.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                  {dep.status === 'confirmed' ? t('status_confirmed') : dep.status === 'pending' ? t('status_pending') : t('status_rejected')}
                </span>
                {dep.status === 'pending' && (
                  <>
                    <button onClick={() => confirmDeposit(dep)} disabled={actionLoading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-500/20 text-primary-400 hover:bg-primary-500/30"><Check className="w-3.5 h-3.5" /> {t('admin_confirm')}</button>
                    <button onClick={() => rejectDeposit(dep)} disabled={actionLoading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-red-500/20 text-red-400 hover:bg-red-500/30"><X className="w-3.5 h-3.5" /> {t('admin_reject')}</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Users */}
      {adminTab === 'users' && (
        <div className="space-y-4 animate-fade-in">
          <input type="text" placeholder={t('admin_search')} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full glass-light rounded-xl py-3 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500/50" />
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm min-w-[640px]">
              <thead><tr className="text-gray-400 text-xs border-b border-white/10">
                <th className="text-left py-3 px-2">{t('admin_name')}</th><th className="text-left py-3 px-2">{t('admin_phone')}</th>
                <th className="text-left py-3 px-2">{t('admin_balance_col')}</th><th className="text-left py-3 px-2">{t('admin_invest_col')}</th>
                <th className="text-left py-3 px-2">{t('admin_profit_col')}</th><th className="text-left py-3 px-2">{t('admin_plan_col')}</th>
                <th className="text-left py-3 px-2">{t('admin_refcode_col')}</th><th className="text-left py-3 px-2">{t('admin_type')}</th>
              </tr></thead>
              <tbody>
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="py-3 px-2 font-medium">{u.full_name || '—'}</td>
                    <td className="py-3 px-2 text-gray-400">{u.phone || '—'}</td>
                    <td className="py-3 px-2 text-primary-400">${num(u.balance).toFixed(2)}</td>
                    <td className="py-3 px-2 text-gray-300">${num(u.total_invested).toFixed(2)}</td>
                    <td className="py-3 px-2 text-gold-400">${num(u.total_profit).toFixed(2)}</td>
                    <td className="py-3 px-2 text-gray-400">{u.plan}</td>
                    <td className="py-3 px-2"><code className="text-xs text-gold-400" dir="ltr">{u.referral_code}</code></td>
                    <td className="py-3 px-2">{u.is_admin ? <span className="text-xs text-gold-400 font-bold">{t('admin_manager')}</span> : <span className="text-xs text-gray-400">{t('admin_regular')}</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add balance */}
      {adminTab === 'addbalance' && (
        <div className="glass rounded-2xl p-5 sm:p-6 space-y-4 max-w-lg animate-fade-in">
          <div>
            <label className="text-sm text-gray-400 mb-2 block">{t('admin_select_user')}</label>
            <select value={addBalanceUser} onChange={(e) => setAddBalanceUser(e.target.value)} className="w-full glass-light rounded-xl py-3 px-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-gold-500/50">
              <option value="" className="bg-navy-900">{t('admin_select_placeholder')}</option>
              {adminUsers.map((u) => <option key={u.id} value={u.id} className="bg-navy-900">{u.full_name || u.id.substring(0, 8)} | {t('admin_balance_label')}: ${num(u.balance).toFixed(2)}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-2 block">{t('admin_op_type')}</label>
            <div className="flex gap-2">
              {[{ val: 'deposit', label: t('admin_add_deposit') }, { val: 'profit', label: t('admin_add_profit') }, { val: 'deduct', label: t('admin_deduct') }].map((o) => (
                <button key={o.val} onClick={() => setAddBalanceType(o.val)} className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${addBalanceType === o.val ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900' : 'glass-light text-gray-400'}`}>{o.label}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm text-gray-400 mb-2 block">{t('admin_amount_usdt')}</label>
            <input type="number" step="any" placeholder="0.00" value={addBalanceAmount} onChange={(e) => setAddBalanceAmount(e.target.value)} dir="ltr" className="w-full glass-light rounded-xl py-3 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500/50 text-right" />
          </div>
          <button onClick={handleAddBalance} disabled={actionLoading} className="w-full py-3.5 rounded-xl font-semibold bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900 hover:scale-105 transition-transform disabled:opacity-60">
            {actionLoading ? t('admin_processing') : t('admin_confirm_op')}
          </button>
        </div>
      )}

      {/* Addresses */}
      {adminTab === 'addresses' && (
        <div className="space-y-3 animate-fade-in">
          {adminAddresses.map((addr) => (
            <div key={addr.id} className="glass rounded-xl p-4 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gold-500/10 flex items-center justify-center font-bold text-gold-400 text-xs">{addr.currency}</div>
                <div>
                  <div className="text-sm font-semibold">{addr.currency} — {addr.network}</div>
                  <input defaultValue={addr.address} onBlur={(e) => { if (e.target.value !== addr.address) updateAddress(addr.id, e.target.value); }} dir="ltr" className="text-xs text-gray-400 bg-transparent border-b border-white/10 mt-1 w-64 focus:outline-none focus:border-gold-500/50" />
                </div>
              </div>
              <button onClick={() => toggleAddress(addr.id, addr.is_active)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${addr.is_active ? 'bg-primary-500/20 text-primary-400' : 'bg-red-500/20 text-red-400'}`}>{addr.is_active ? t('admin_enabled') : t('admin_disabled')}</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
