import { UserPlus, Flame, Coins, Wallet } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

export default function HowItWorks() {
  const { t } = useLang();

  const steps = [
    { icon: UserPlus, num: '01', title: t('how_1_t'), desc: t('how_1_d') },
    { icon: Flame, num: '02', title: t('how_2_t'), desc: t('how_2_d') },
    { icon: Coins, num: '03', title: t('how_3_t'), desc: t('how_3_d') },
    { icon: Wallet, num: '04', title: t('how_4_t'), desc: t('how_4_d') },
  ];

  return (
    <section id="how" className="py-16 sm:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-light rounded-full px-4 py-2 mb-4">
            <Wallet className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-300">{t('how_badge')}</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold">
            {t('how_title_1')} <span className="text-gradient-cyan">{t('how_title_2')}</span>
          </h2>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t('how_desc')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          <div className="hidden lg:block absolute top-16 inset-x-12 h-px bg-gradient-to-r from-transparent via-primary-500/20 to-transparent" />

          {steps.map((step) => (
            <div
              key={step.num}
              className="relative glass rounded-2xl p-7 text-center hover:bg-white/8 transition-all duration-300 hover:scale-[1.03] group"
            >
              <div className="relative inline-flex">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-500/20 to-accent-500/20 flex items-center justify-center mb-5 group-hover:from-primary-500/30 group-hover:to-accent-500/30 transition-all">
                  <step.icon className="w-8 h-8 text-primary-400" />
                </div>
                <span className="absolute -top-2 -right-2 text-xs font-bold text-white/30">
                  {step.num}
                </span>
              </div>
              <h3 className="text-lg font-bold mb-3">{step.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
