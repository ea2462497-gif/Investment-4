import { Flame, Crown, Gem, Star, Award } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';

const vipLevels = [
  { level: 'VIP 1', icon: Star, color: 'text-primary-400' },
  { level: 'VIP 2', icon: Award, color: 'text-accent-400' },
  { level: 'VIP 3', icon: Flame, color: 'text-gold-500' },
  { level: 'VIP 4', icon: Crown, color: 'text-gold-400' },
  { level: 'VIP 5', icon: Gem, color: 'text-cyan-300' },
];

function maskIdentifier(id: string): string {
  if (id.includes('@')) {
    const [name, domain] = id.split('@');
    if (name.length <= 2) return id;
    return name.slice(0, 2) + '***@' + domain;
  }
  if (id.length <= 4) return id;
  return id.slice(0, 3) + '****' + id.slice(-2);
}

const tickerItems = [
  { vip: 0, amount: 1.6, id: '966512***89' },
  { vip: 1, amount: 7, id: 'ah***@gmail.com' },
  { vip: 2, amount: 28, id: '966553***12' },
  { vip: 0, amount: 1.6, id: 'mo***@hotmail.com' },
  { vip: 3, amount: 99, id: '966502***45' },
  { vip: 4, amount: 252, id: 'kh***@yahoo.com' },
  { vip: 1, amount: 7, id: '966570***33' },
  { vip: 2, amount: 28, id: 'sa***@gmail.com' },
  { vip: 0, amount: 1.6, id: '966540***78' },
  { vip: 4, amount: 518, id: 'no***@outlook.com' },
  { vip: 3, amount: 99, id: '966533***91' },
  { vip: 2, amount: 28, id: 'fa***@gmail.com' },
  { vip: 1, amount: 7, id: '966590***22' },
  { vip: 0, amount: 1.6, id: 'om***@hotmail.com' },
  { vip: 4, amount: 2059, id: '966511***67' },
  { vip: 3, amount: 252, id: 'la***@yahoo.com' },
  { vip: 2, amount: 986, id: '966562***84' },
  { vip: 1, amount: 7, id: 'ra***@gmail.com' },
  { vip: 0, amount: 1.6, id: '966580***55' },
  { vip: 3, amount: 99, id: 'ta***@hotmail.com' },
];

function TickerCard({ item }: { item: typeof tickerItems[0] }) {
  const vip = vipLevels[item.vip];
  const Icon = vip.icon;
  return (
    <div className="flex-shrink-0 glass-light rounded-xl px-5 py-3 mx-2 flex items-center gap-3 min-w-[260px]">
      <div className={`w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0`}>
        <Icon className={`w-5 h-5 ${vip.color}`} />
      </div>
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold ${vip.color}`}>{vip.level}</span>
          <span className="text-xs text-gray-500">·</span>
          <span className="text-sm font-bold text-primary-400">+${item.amount.toLocaleString()}</span>
        </div>
        <span className="text-xs text-gray-500" dir="ltr">{maskIdentifier(item.id)}</span>
      </div>
    </div>
  );
}

export default function ProfitTicker() {
  const { t } = useLang();
  const doubled = [...tickerItems, ...tickerItems];

  return (
    <section className="py-6 relative overflow-hidden border-y border-white/5 bg-navy-900/50">
      <div className="text-center mb-3">
        <span className="text-xs text-gray-500 flex items-center justify-center gap-1.5">
          <Flame className="w-3.5 h-3.5 text-primary-400" />
          {t('ticker_title')}
        </span>
      </div>
      <div className="relative overflow-hidden">
        <div className="flex animate-marquee hover:[animation-play-state:paused]">
          {doubled.map((item, i) => (
            <TickerCard key={i} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}
