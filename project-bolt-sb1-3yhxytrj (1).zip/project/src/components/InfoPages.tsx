import { ArrowLeft, Flame, Target, Eye, Heart, FileText, Shield } from 'lucide-react';
import { useLang } from '@/context/LanguageContext';
import Navbar from './Navbar';
import Footer from './Footer';

type Page = 'about' | 'terms' | 'privacy';

type Props = {
  page: Page;
  onBack: () => void;
  onNavigate?: (page: Page) => void;
};

export default function InfoPages({ page, onBack, onNavigate }: Props) {
  const { t, dir } = useLang();

  const content: Record<Page, { title: string; intro: string; sections: { t: string; d: string }[]; icon: typeof Flame }> = {
    about: {
      title: t('about_title'),
      intro: t('about_intro'),
      icon: Flame,
      sections: [
        { t: t('about_mission_t'), d: t('about_mission_d') },
        { t: t('about_vision_t'), d: t('about_vision_d') },
        { t: t('about_values_t'), d: t('about_values_d') },
      ],
    },
    terms: {
      title: t('terms_title'),
      intro: t('terms_intro'),
      icon: FileText,
      sections: [
        { t: t('terms_1_t'), d: t('terms_1_d') },
        { t: t('terms_2_t'), d: t('terms_2_d') },
        { t: t('terms_3_t'), d: t('terms_3_d') },
        { t: t('terms_4_t'), d: t('terms_4_d') },
        { t: t('terms_5_t'), d: t('terms_5_d') },
        { t: t('terms_6_t'), d: t('terms_6_d') },
      ],
    },
    privacy: {
      title: t('privacy_title'),
      intro: t('privacy_intro'),
      icon: Shield,
      sections: [
        { t: t('privacy_1_t'), d: t('privacy_1_d') },
        { t: t('privacy_2_t'), d: t('privacy_2_d') },
        { t: t('privacy_3_t'), d: t('privacy_3_d') },
        { t: t('privacy_4_t'), d: t('privacy_4_d') },
        { t: t('privacy_5_t'), d: t('privacy_5_d') },
      ],
    },
  };

  const pageData = content[page];
  const icons = { about: [Target, Eye, Heart], terms: [FileText, FileText, FileText, FileText, FileText, FileText], privacy: [Shield, Shield, Shield, Shield, Shield] };
  const pageIcons = icons[page];

  return (
    <div className="min-h-screen bg-navy-950 text-white overflow-x-hidden">
      <Navbar onGetStarted={onBack} onSignIn={onBack} />

      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-600/15 rounded-full blur-3xl animate-pulse-slow" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors mb-8"
          >
            <ArrowLeft className={`w-4 h-4 ${dir === 'ltr' ? 'rotate-180' : ''}`} />
            {t('auth_back')}
          </button>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center glow-primary flex-shrink-0">
              <pageData.icon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold">{pageData.title}</h1>
              <p className="text-sm text-gray-400 mt-1">{page === 'about' ? t('about_desc') : page === 'terms' ? t('terms_intro') : t('privacy_intro')}</p>
            </div>
          </div>

          <div className="glass rounded-3xl p-6 sm:p-10 mb-8">
            <p className="text-gray-300 leading-relaxed text-base sm:text-lg">{pageData.intro}</p>
          </div>

          <div className="space-y-4">
            {pageData.sections.map((section, i) => {
              const Icon = pageIcons[i] ?? FileText;
              return (
                <div key={i} className="glass rounded-2xl p-5 sm:p-7 hover:bg-white/5 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary-500/20 to-accent-500/20 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-primary-400" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-lg font-bold mb-2">{section.t}</h3>
                      <p className="text-gray-400 text-sm leading-relaxed">{section.d}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <Footer onNavigate={(p) => { window.scrollTo(0, 0); onNavigate?.(p); }} />
    </div>
  );
}
