import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Stats from '@/components/Stats';
import Plans from '@/components/Plans';
import Features from '@/components/Features';
import HowItWorks from '@/components/HowItWorks';
import Testimonials from '@/components/Testimonials';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';
import AuthPage from '@/components/AuthPage';
import Dashboard from '@/components/Dashboard';
import InfoPages from '@/components/InfoPages';
import ProfitTicker from '@/components/ProfitTicker';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [infoPage, setInfoPage] = useState<'about' | 'terms' | 'privacy' | null>(null);
  const [forceStop, setForceStop] = useState(false);

  useEffect(() => {
    if (!loading) return;
    const timer = setTimeout(() => setForceStop(true), 5000);
    return () => clearTimeout(timer);
  }, [loading]);

  useEffect(() => {
    if (user) setShowAuth(false);
  }, [user]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('ref')) {
      setShowAuth(true);
    }
  }, []);

  if (loading && !forceStop) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-primary-400 animate-spin" />
      </div>
    );
  }

  if (user) {
    return <Dashboard />;
  }

  if (infoPage) {
    return <InfoPages page={infoPage} onBack={() => setInfoPage(null)} onNavigate={(p) => setInfoPage(p)} />;
  }

  if (showAuth) {
    return <AuthPage onBack={() => setShowAuth(false)} />;
  }

  return (
    <div className="min-h-screen bg-navy-950 text-white overflow-x-hidden">
      <Navbar
        onGetStarted={() => setShowAuth(true)}
        onSignIn={() => setShowAuth(true)}
      />
      <main>
        <Hero />
        <ProfitTicker />
        <Stats />
        <Plans />
        <Features />
        <HowItWorks />
        <Testimonials />
        <FAQ />
        <Footer onNavigate={(page) => setInfoPage(page)} />
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
