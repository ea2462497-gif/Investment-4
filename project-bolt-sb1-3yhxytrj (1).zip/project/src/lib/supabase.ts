import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Profile = {
  id: string;
  full_name: string;
  phone: string;
  balance: number;
  total_invested: number;
  total_profit: number;
  plan: string;
  is_admin: boolean;
  referral_code: string;
  referred_by: string;
  created_at: string;
  updated_at: string;
};

export type Deposit = {
  id: string;
  user_id: string;
  currency: string;
  amount: number;
  tx_hash: string;
  status: string;
  plan: string;
  created_at: string;
};

export type Transaction = {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  status: string;
  description: string;
  created_at: string;
};

export type Investment = {
  id: string;
  user_id: string;
  plan: string;
  amount: number;
  expected_return: number;
  status: string;
  start_date: string;
  end_date: string;
  created_at: string;
};

export type DepositAddress = {
  id: string;
  currency: string;
  network: string;
  address: string;
  is_active: boolean;
  created_at: string;
};

export type Referral = {
  id: string;
  referrer_id: string;
  referred_id: string;
  referral_code: string;
  reward: number;
  status: string;
  created_at: string;
};

export type MiningInvestment = {
  id: string;
  user_id: string;
  plan_code: string;
  invest_amount: number;
  daily_earn: number;
  status: string;
  start_date: string;
  last_claim: string;
  total_earned: number;
  created_at: string;
};

export function num(v: unknown): number {
  const n = Number(v);
  return isNaN(n) ? 0 : n;
}

export type Withdrawal = {
  id: string;
  user_id: string;
  currency: string;
  amount: number;
  wallet_address: string;
  status: string;
  tx_hash: string | null;
  created_at: string;
  updated_at: string;
};
