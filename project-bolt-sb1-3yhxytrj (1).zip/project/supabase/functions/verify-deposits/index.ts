import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false },
});

const TRONGRID_API = "https://api.trongrid.io";

interface TronTx {
  transaction_id: string;
  to: string;
  from: string;
  value: number;
  block_timestamp: number;
}

async function fetchTrc20Transactions(address: string): Promise<TronTx[]> {
  try {
    const url = `${TRONGRID_API}/v1/accounts/${address}/transactions/trc20?limit=50&order_by=block_timestamp,desc`;
    const resp = await fetch(url, {
      headers: { "accept": "application/json" },
    });

    if (!resp.ok) return [];

    const data = await resp.json();
    if (!data.data || !Array.isArray(data.data)) return [];

    return data.data.map((tx: Record<string, unknown>) => ({
      transaction_id: tx.transaction_id as string,
      to: tx.to as string,
      from: tx.from as string,
      value: Number(tx.value) / Math.pow(10, (tx.token_info as Record<string, number>)?.decimals ?? 6),
      block_timestamp: tx.block_timestamp as number,
    }));
  } catch {
    return [];
  }
}

async function fetchTrxTransactions(address: string): Promise<TronTx[]> {
  try {
    const url = `${TRONGRID_API}/v1/accounts/${address}/transactions?limit=50&order_by=block_timestamp,desc`;
    const resp = await fetch(url, {
      headers: { "accept": "application/json" },
    });

    if (!resp.ok) return [];

    const data = await resp.json();
    if (!data.data || !Array.isArray(data.data)) return [];

    return data.data.map((tx: Record<string, unknown>) => ({
      transaction_id: (tx.tx_id as string) ?? "",
      to: address,
      from: tx.from as string,
      value: Number(tx.amount ?? 0) / 1_000_000,
      block_timestamp: tx.block_timestamp as number,
    }));
  } catch {
    return [];
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    // 1. Get all active deposit addresses
    const { data: addresses, error: addrError } = await supabase
      .from("deposit_addresses")
      .select("*")
      .eq("is_active", true);

    if (addrError) {
      return new Response(
        JSON.stringify({ error: addrError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!addresses || addresses.length === 0) {
      return new Response(
        JSON.stringify({ message: "No deposit addresses configured", credited: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Get all pending deposits, ordered oldest first (FIFO queue)
    const { data: pendingDeposits, error: depError } = await supabase
      .from("deposits")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: true })
      .limit(100);

    if (depError) {
      return new Response(
        JSON.stringify({ error: depError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!pendingDeposits || pendingDeposits.length === 0) {
      return new Response(
        JSON.stringify({ message: "No pending deposits to verify", credited: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let totalCredited = 0;
    const usedTxHashes: Set<string> = new Set();

    // 3. For each deposit address, fetch blockchain transactions
    for (const addr of addresses) {
      const network = (addr as Record<string, string>).network?.toUpperCase() ?? "";
      const currency = (addr as Record<string, string>).currency?.toUpperCase() ?? "";
      const addressStr = (addr as Record<string, string>).address ?? "";

      let txs: TronTx[] = [];

      if (network.includes("TRC20") || network.includes("TRON")) {
        if (currency === "USDT" || currency === "USDC") {
          txs = await fetchTrc20Transactions(addressStr);
        } else if (currency === "TRX") {
          txs = await fetchTrxTransactions(addressStr);
        }
      }

      if (txs.length === 0) continue;

      // Only consider transactions from the last 24 hours, sorted oldest first
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      const recentTxs = txs
        .filter(tx => tx.block_timestamp > cutoff)
        .sort((a, b) => a.block_timestamp - b.block_timestamp);

      // 4. Match pending deposits to transactions in FIFO order
      // Each pending deposit (oldest first) gets matched to the next available
      // unclaimed transaction (oldest first) for the same currency.
      for (const deposit of pendingDeposits) {
        const depCurrency = (deposit as Record<string, string>).currency?.toUpperCase() ?? "";
        if (depCurrency !== currency) continue;

        // Find the next unclaimed transaction for this currency
        const matchedTx = recentTxs.find(tx => !usedTxHashes.has(tx.transaction_id));

        if (matchedTx && matchedTx.value > 0) {
          // Verify this tx_hash hasn't already been credited to another deposit
          const { data: existingTx } = await supabase
            .from("deposits")
            .select("id")
            .eq("tx_hash", matchedTx.transaction_id)
            .neq("id", (deposit as Record<string, unknown>).id as string)
            .maybeSingle();

          if (existingTx) {
            usedTxHashes.add(matchedTx.transaction_id);
            continue;
          }

          const depositId = (deposit as Record<string, unknown>).id as string;
          const userId = (deposit as Record<string, unknown>).user_id as string;
          const amount = matchedTx.value;

          const { error: creditError } = await supabase.rpc("credit_verified_deposit", {
            p_deposit_id: depositId,
            p_user_id: userId,
            p_amount: amount,
            p_tx_hash: matchedTx.transaction_id,
          });

          if (!creditError) {
            totalCredited++;
            usedTxHashes.add(matchedTx.transaction_id);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        message: `Verified deposits. Credited ${totalCredited} deposits.`,
        credited: totalCredited,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
