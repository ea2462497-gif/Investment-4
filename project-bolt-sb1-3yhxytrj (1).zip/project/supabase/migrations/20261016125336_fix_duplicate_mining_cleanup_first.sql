-- 1. Delete duplicate mining subscriptions, keeping only the most recent per (user_id, plan_code)
DELETE FROM mining_investments
WHERE id NOT IN (
  SELECT DISTINCT ON (user_id, plan_code) id
  FROM mining_investments
  WHERE status = 'active'
  ORDER BY user_id, plan_code, created_at DESC
)
AND status = 'active';

-- 2. Now add unique constraint to prevent future duplicates
CREATE UNIQUE INDEX IF NOT EXISTS mining_investments_user_plan_active_idx
  ON mining_investments (user_id, plan_code)
  WHERE status = 'active';
