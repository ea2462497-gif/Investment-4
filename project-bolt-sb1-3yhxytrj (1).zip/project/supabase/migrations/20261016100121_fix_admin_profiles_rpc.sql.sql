-- Fix: admin can't see all profiles because select_own_profile RLS
-- blocks reading is_admin from other rows (subquery hits same RLS).
-- Create a SECURITY DEFINER function that bypasses RLS to list all users.

CREATE OR REPLACE FUNCTION public.get_all_profiles_admin()
RETURNS TABLE (
  id uuid,
  full_name text,
  phone text,
  balance numeric,
  total_invested numeric,
  total_profit numeric,
  plan text,
  is_admin boolean,
  referral_code text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, full_name, phone, balance, total_invested, total_profit,
         plan, is_admin, referral_code, created_at
  FROM profiles
  ORDER BY created_at DESC;
$$;

-- Only allow admins to call it
REVOKE EXECUTE ON FUNCTION public.get_all_profiles_admin() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_all_profiles_admin() TO authenticated;
