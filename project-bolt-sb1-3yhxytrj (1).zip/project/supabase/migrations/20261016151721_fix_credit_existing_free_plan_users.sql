/*
 # Fix: Credit free plan profit to existing users who activated before the fix

 Users who activated SNB-0 before the immediate-credit fix have:
 - mining_investments row with total_earned = 0
 - balance = 0 (no profit was ever credited)

 This migration credits 1.6 USDT to each such user and updates their
 mining_investments.total_earned to reflect it.
*/

-- Credit 1.6 USDT balance + total_profit to users with SNB-0 and total_earned = 0
UPDATE profiles p
SET
  balance = p.balance + 1.6,
  total_profit = p.total_profit + 1.6,
  updated_at = now()
FROM mining_investments mi
WHERE mi.user_id = p.id
  AND mi.plan_code = 'SNB-0'
  AND mi.status = 'active'
  AND mi.total_earned = 0;

-- Update mining_investments.total_earned to 1.6 for those rows
UPDATE mining_investments mi
SET
  total_earned = 1.6,
  last_claim = now()
WHERE mi.plan_code = 'SNB-0'
  AND mi.status = 'active'
  AND mi.total_earned = 0;

-- Insert transactions for these credits
INSERT INTO transactions (user_id, type, amount, status, description)
SELECT mi.user_id, 'mining_profit', 1.6, 'completed', 'Free plan SNB-0 activation credit (1 day)'
FROM mining_investments mi
WHERE mi.plan_code = 'SNB-0'
  AND mi.status = 'active'
  AND mi.total_earned = 1.6
  AND NOT EXISTS (
    SELECT 1 FROM transactions t
    WHERE t.user_id = mi.user_id
      AND t.type = 'mining_profit'
      AND t.amount = 1.6
      AND t.description LIKE '%SNB-0 activation%'
  );
