/*
 # Fix: referral code keeps getting overwritten on each login
 # Fix: admin_update_balance callable by any authenticated user (security hole)
 # Fix: get_all_profiles_admin callable by any authenticated user (security hole)

 ## Root cause
 1. loadProfile fetches profile → if RLS/timing prevents it, it generates a NEW code
    and calls create_user_profile which ON CONFLICT overwrites referral_code
 2. create_user_profile ON CONFLICT DO UPDATE sets referral_code even when a code
    already exists (because COALESCE(NULLIF(new, ''), old) keeps new when new != '')
 3. admin_update_balance has no admin check — any logged-in user can call it
 4. get_all_profiles_admin has no admin check — any logged-in user can call it
*/

-- 1. Fix create_user_profile: NEVER overwrite referral_code if it already exists
CREATE OR REPLACE FUNCTION public.create_user_profile(
  p_user_id uuid,
  p_full_name text DEFAULT '',
  p_phone text DEFAULT '',
  p_referral_code text DEFAULT '',
  p_referred_by text DEFAULT ''
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, full_name, phone, referral_code, referred_by)
  VALUES (p_user_id, p_full_name, p_phone, p_referral_code, p_referred_by)
  ON CONFLICT (id) DO UPDATE SET
    full_name = COALESCE(NULLIF(p_full_name, ''), profiles.full_name),
    phone = COALESCE(NULLIF(p_phone, ''), profiles.phone),
    referral_code = profiles.referral_code,  -- NEVER overwrite existing code
    referred_by = COALESCE(NULLIF(p_referred_by, ''), profiles.referred_by),
    updated_at = now();
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) TO authenticated, anon;

-- 2. Fix admin_update_balance: add admin check, restrict to admins only
CREATE OR REPLACE FUNCTION public.admin_update_balance(
  p_user_id uuid,
  p_balance numeric DEFAULT NULL,
  p_total_invested numeric DEFAULT NULL,
  p_total_profit numeric DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;
  UPDATE profiles
  SET
    balance = COALESCE(p_balance, balance),
    total_invested = COALESCE(p_total_invested, total_invested),
    total_profit = COALESCE(p_total_profit, total_profit),
    updated_at = now()
  WHERE id = p_user_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) TO authenticated;

-- 3. Fix get_all_profiles_admin: add admin check
CREATE OR REPLACE FUNCTION public.get_all_profiles_admin()
RETURNS TABLE (
  id uuid,
  full_name text,
  phone text,
  balance numeric,
  total_invested numeric,
  total_profit numeric,
  plan text,
  is_admin boolean,
  referral_code text,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;
  RETURN QUERY SELECT
    p.id, p.full_name, p.phone, p.balance, p.total_invested, p.total_profit,
    p.plan, p.is_admin, p.referral_code, p.created_at
  FROM profiles p
  ORDER BY p.created_at DESC;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_all_profiles_admin() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_all_profiles_admin() TO authenticated;
