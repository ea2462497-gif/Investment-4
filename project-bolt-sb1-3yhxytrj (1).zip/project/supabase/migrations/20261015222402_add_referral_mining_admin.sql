/*
# Referral Program, Mining Plans, and Admin Role

## Changes
### profiles (modified)
- Added is_admin boolean (default false)
- Added referral_code text (unique invite code per user)
- Added referred_by text (stores referral code of inviter)

### referrals (new table)
- Tracks who referred whom, with reward and status

### mining_investments (new table)
- Tracks SNB mining plan subscriptions with daily earnings

### generate_referral_code function
- SECURITY DEFINER function that creates unique codes like RASXXXXXX

## Security
- RLS on all new tables, owner-scoped
*/

-- ===== ADD COLUMNS TO PROFILES =====
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS referral_code text DEFAULT '';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS referred_by text DEFAULT '';

CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_referral_code ON profiles(referral_code) WHERE referral_code != '';

-- ===== REFERRALS TABLE =====
CREATE TABLE IF NOT EXISTS referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referral_code text NOT NULL DEFAULT '',
  reward numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_referrals" ON referrals;
CREATE POLICY "select_own_referrals" ON referrals FOR SELECT
  TO authenticated USING (auth.uid() = referrer_id OR auth.uid() = referred_id);

DROP POLICY IF EXISTS "insert_own_referrals" ON referrals;
CREATE POLICY "insert_own_referrals" ON referrals FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = referrer_id OR auth.uid() = referred_id);

DROP POLICY IF EXISTS "update_own_referrals" ON referrals;
CREATE POLICY "update_own_referrals" ON referrals FOR UPDATE
  TO authenticated USING (auth.uid() = referrer_id) WITH CHECK (auth.uid() = referrer_id);

-- ===== MINING INVESTMENTS TABLE =====
CREATE TABLE IF NOT EXISTS mining_investments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_code text NOT NULL,
  invest_amount numeric NOT NULL DEFAULT 0,
  daily_earn numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  start_date timestamptz DEFAULT now(),
  last_claim timestamptz DEFAULT now(),
  total_earned numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE mining_investments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_mining" ON mining_investments;
CREATE POLICY "select_own_mining" ON mining_investments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_mining" ON mining_investments;
CREATE POLICY "insert_own_mining" ON mining_investments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_mining" ON mining_investments;
CREATE POLICY "update_own_mining" ON mining_investments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_mining" ON mining_investments;
CREATE POLICY "delete_own_mining" ON mining_investments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_mining_user_id ON mining_investments(user_id);

-- ===== GENERATE REFerral CODE FUNCTION =====
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 'RAS' || UPPER(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
$$;
