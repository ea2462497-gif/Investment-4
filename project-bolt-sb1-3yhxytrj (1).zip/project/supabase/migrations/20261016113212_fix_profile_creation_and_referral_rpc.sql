/*
# Fix profile creation, referral code generation, and free plan activation

## Problems
1. signUp inserts profile via RLS which can fail if session not established yet
2. loadProfile insert can conflict with existing profile from signUp
3. generate_referral_code missing SET search_path (security risk)
4. No reliable way to create profile with all fields server-side

## Changes
1. New SECURITY DEFINER function create_user_profile that inserts/updates profile
   with all fields (full_name, phone, referral_code, referred_by) — bypasses RLS
2. Fix generate_referral_code to have SET search_path = public
3. Grant execute to anon + authenticated for create_user_profile (called during signUp)
*/

-- Fix generate_referral_code: add SET search_path
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 'RAS' || UPPER(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
$$;

REVOKE EXECUTE ON FUNCTION public.generate_referral_code() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.generate_referral_code() TO authenticated, anon;

-- New function: create or update user profile with all fields
-- Called during signUp to ensure profile is created reliably even if
-- the RLS session check fails on direct insert
CREATE OR REPLACE FUNCTION public.create_user_profile(
  p_user_id uuid,
  p_full_name text DEFAULT '',
  p_phone text DEFAULT '',
  p_referral_code text DEFAULT '',
  p_referred_by text DEFAULT ''
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, full_name, phone, referral_code, referred_by)
  VALUES (p_user_id, p_full_name, p_phone, p_referral_code, p_referred_by)
  ON CONFLICT (id) DO UPDATE SET
    full_name = COALESCE(NULLIF(p_full_name, ''), profiles.full_name),
    phone = COALESCE(NULLIF(p_phone, ''), profiles.phone),
    referral_code = COALESCE(NULLIF(p_referral_code, ''), profiles.referral_code),
    referred_by = COALESCE(NULLIF(p_referred_by, ''), profiles.referred_by),
    updated_at = now();
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) TO authenticated, anon;
