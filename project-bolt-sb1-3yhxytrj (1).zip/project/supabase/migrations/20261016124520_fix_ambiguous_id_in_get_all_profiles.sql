-- Fix: ambiguous column reference "id" in get_all_profiles_admin
-- The RETURN TABLE column "id" shadows the profiles.id in the EXISTS check
CREATE OR REPLACE FUNCTION public.get_all_profiles_admin()
RETURNS TABLE (
  id uuid,
  full_name text,
  phone text,
  balance numeric,
  total_invested numeric,
  total_profit numeric,
  plan text,
  is_admin boolean,
  referral_code text,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;
  RETURN QUERY SELECT
    p.id, p.full_name, p.phone, p.balance, p.total_invested, p.total_profit,
    p.plan, p.is_admin, p.referral_code, p.created_at
  FROM profiles p
  ORDER BY p.created_at DESC;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_all_profiles_admin() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_all_profiles_admin() TO authenticated;
