/*
 # ROOT CAUSE FIX: Infinite recursion in RLS policies on profiles

 The SELECT/UPDATE policies on profiles had:
   EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true)
 This queries profiles INSIDE a policy ON profiles → infinite recursion →
 every query to profiles fails silently → no balance, no referral code, no admin users.

 Fix: Replace the subquery with public.is_current_user_admin() which is
 SECURITY DEFINER (runs as postgres, bypasses RLS) → no recursion.

 Also fix the same pattern on deposits, investments, mining_investments,
 transactions, referrals, withdrawals — all have the same subquery pattern.
*/

-- 1. profiles: drop and recreate policies
DROP POLICY IF EXISTS select_own_profile ON profiles;
DROP POLICY IF EXISTS update_own_profile ON profiles;
DROP POLICY IF EXISTS insert_own_profile ON profiles;
DROP POLICY IF EXISTS delete_own_profile ON profiles;

CREATE POLICY select_own_profile ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_current_user_admin());

CREATE POLICY update_own_profile ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id OR public.is_current_user_admin())
  WITH CHECK (auth.uid() = id OR public.is_current_user_admin());

CREATE POLICY insert_own_profile ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

-- 2. deposits: fix admin subquery
DROP POLICY IF EXISTS select_own_deposits ON deposits;
DROP POLICY IF EXISTS update_own_deposits ON deposits;

CREATE POLICY select_own_deposits ON deposits
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin());

CREATE POLICY update_own_deposits ON deposits
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin())
  WITH CHECK (auth.uid() = user_id OR public.is_current_user_admin());

-- 3. investments: fix admin subquery
DROP POLICY IF EXISTS select_own_investments ON investments;

CREATE POLICY select_own_investments ON investments
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin());

-- 4. mining_investments: fix admin subquery
DROP POLICY IF EXISTS select_own_mining ON mining_investments;

CREATE POLICY select_own_mining ON mining_investments
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin());

-- 5. transactions: fix admin subquery
DROP POLICY IF EXISTS select_own_transactions ON transactions;
DROP POLICY IF EXISTS insert_own_transactions ON transactions;

CREATE POLICY select_own_transactions ON transactions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin());

CREATE POLICY insert_own_transactions ON transactions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id OR public.is_current_user_admin());

-- 6. referrals: fix admin subquery
DROP POLICY IF EXISTS select_own_referrals ON referrals;

CREATE POLICY select_own_referrals ON referrals
  FOR SELECT TO authenticated
  USING (auth.uid() = referrer_id OR auth.uid() = referred_id OR public.is_current_user_admin());

-- 7. withdrawals: fix admin subquery
DROP POLICY IF EXISTS select_own_withdrawals ON withdrawals;
DROP POLICY IF EXISTS update_own_withdrawals ON withdrawals;

CREATE POLICY select_own_withdrawals ON withdrawals
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin());

CREATE POLICY update_own_withdrawals ON withdrawals
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.is_current_user_admin())
  WITH CHECK (auth.uid() = user_id OR public.is_current_user_admin());
