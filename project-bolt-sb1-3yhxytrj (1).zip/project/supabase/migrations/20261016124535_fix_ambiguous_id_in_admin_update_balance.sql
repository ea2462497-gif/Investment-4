-- Fix: ambiguous column reference "id" in admin_update_balance
CREATE OR REPLACE FUNCTION public.admin_update_balance(
  p_user_id uuid,
  p_balance numeric DEFAULT NULL,
  p_total_invested numeric DEFAULT NULL,
  p_total_profit numeric DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;
  UPDATE profiles
  SET
    balance = COALESCE(p_balance, balance),
    total_invested = COALESCE(p_total_invested, total_invested),
    total_profit = COALESCE(p_total_profit, total_profit),
    updated_at = now()
  WHERE id = p_user_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) TO authenticated;
