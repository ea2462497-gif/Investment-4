/*
# Auto-verify deposits via blockchain and credit user balance

## Purpose
When a user clicks "تم الإيداع" (I have deposited), a pending deposit record is created
with amount=0 and no tx_hash. An edge function (verify-deposits) scans the blockchain
for incoming transactions to the platform's deposit addresses, matches them to pending
deposits, and calls this RPC to atomically credit the user's balance.

## Changes
1. New RPC function `credit_verified_deposit(p_deposit_id, p_user_id, p_amount, p_tx_hash)`:
   - SECURITY DEFINER (runs with service role privileges, bypasses RLS)
   - Atomically updates the deposit record: sets amount, tx_hash, and status='completed'
   - Atomically credits the user's profile balance, total_invested, and total_deposit
   - Inserts a transaction record for audit trail
   - Returns true on success
   - Guards against double-crediting (checks deposit status is still 'pending')
2. Security:
   - REVOKE EXECUTE from PUBLIC and anon (only authenticated + service_role can call)
   - Function is SECURITY DEFINER so it can update profiles even though the caller
     (edge function with service_role) already bypasses RLS

## Important Notes
- This function is idempotent: if called twice for the same deposit, the second call
  is a no-op because the status will no longer be 'pending'
- The edge function uses the service_role key which bypasses RLS entirely
- Withdrawals remain manual (require admin approval) — this only affects deposits
*/

CREATE OR REPLACE FUNCTION credit_verified_deposit(
  p_deposit_id uuid,
  p_user_id uuid,
  p_amount numeric,
  p_tx_hash text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_status text;
  v_current_balance numeric;
  v_current_invested numeric;
BEGIN
  -- Check the deposit is still pending (prevent double-crediting)
  SELECT status INTO v_current_status
  FROM deposits
  WHERE id = p_deposit_id AND user_id = p_user_id
  FOR UPDATE;

  IF v_current_status IS NULL THEN
    RETURN false;
  END IF;

  IF v_current_status != 'pending' THEN
    -- Already processed, no-op
    RETURN false;
  END IF;

  -- Get current profile values
  SELECT balance, total_invested INTO v_current_balance, v_current_invested
  FROM profiles
  WHERE id = p_user_id
  FOR UPDATE;

  -- Update deposit record
  UPDATE deposits
  SET amount = p_amount,
      tx_hash = p_tx_hash,
      status = 'completed'
  WHERE id = p_deposit_id AND user_id = p_user_id;

  -- Credit user balance
  UPDATE profiles
  SET balance = COALESCE(v_current_balance, 0) + p_amount,
      total_invested = COALESCE(v_current_invested, 0) + p_amount,
      updated_at = now()
  WHERE id = p_user_id;

  -- Insert transaction record
  INSERT INTO transactions (user_id, type, amount, status, description)
  VALUES (p_user_id, 'deposit', p_amount, 'completed', 'Deposit verified on blockchain');

  RETURN true;
END;
$$;

-- Revoke from PUBLIC and anon, grant only to authenticated and service_role
REVOKE EXECUTE ON FUNCTION credit_verified_deposit(uuid, uuid, numeric, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION credit_verified_deposit(uuid, uuid, numeric, text) TO authenticated;
