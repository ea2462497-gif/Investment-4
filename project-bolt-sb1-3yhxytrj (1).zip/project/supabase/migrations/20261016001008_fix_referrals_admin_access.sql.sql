/*
# Fix referral system and admin access

## Problems Fixed
1. Referral INSERT was failing because the policy required auth.uid() to match
   referrer_id or referred_id, but the new user's session wasn't fully established
   at the time of insert. Fixed by allowing any authenticated user to insert
   referral records (the application logic validates the referral code).
2. Admin users could not see other users' profiles because the SELECT policy
   only allowed auth.uid() = id. Added admin read access via is_admin check.
3. Admin users could not see all deposits, withdrawals, or transactions.
   Added admin read/update access to deposits, withdrawals, transactions,
   mining_investments, and referrals tables.
4. Added admin ability to update withdrawal statuses (confirm/reject).

## Security Changes
- profiles: admin users (is_admin = true) can SELECT all profiles
- profiles: admin users can UPDATE all profiles (for balance management)
- deposits: admin users can SELECT and UPDATE all deposits
- withdrawals: admin users can SELECT and UPDATE all withdrawals
- transactions: admin users can SELECT and INSERT all transactions
- referrals: any authenticated user can INSERT (application validates codes)
- referrals: admin users can SELECT all referrals
- mining_investments: admin users can SELECT all
- deposit_addresses: admin users can UPDATE addresses
*/

-- Profiles: admin can read all
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile"
ON profiles FOR SELECT
TO authenticated
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Profiles: admin can update all
DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
))
WITH CHECK (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Deposits: admin can read all
DROP POLICY IF EXISTS "select_own_deposits" ON deposits;
CREATE POLICY "select_own_deposits"
ON deposits FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Deposits: admin can update all
DROP POLICY IF EXISTS "update_own_deposits" ON deposits;
CREATE POLICY "update_own_deposits"
ON deposits FOR UPDATE
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
))
WITH CHECK (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Withdrawals: admin can read all
DROP POLICY IF EXISTS "select_own_withdrawals" ON withdrawals;
CREATE POLICY "select_own_withdrawals"
ON withdrawals FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Withdrawals: admin can update all
DROP POLICY IF EXISTS "update_own_withdrawals" ON withdrawals;
CREATE POLICY "update_own_withdrawals"
ON withdrawals FOR UPDATE
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
))
WITH CHECK (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Transactions: admin can read all
DROP POLICY IF EXISTS "select_own_transactions" ON transactions;
CREATE POLICY "select_own_transactions"
ON transactions FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Transactions: admin can insert for any user
DROP POLICY IF EXISTS "insert_own_transactions" ON transactions;
CREATE POLICY "insert_own_transactions"
ON transactions FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Referrals: any authenticated user can insert (application validates codes)
DROP POLICY IF EXISTS "insert_own_referrals" ON referrals;
CREATE POLICY "insert_own_referrals"
ON referrals FOR INSERT
TO authenticated
WITH CHECK (true);

-- Referrals: admin can read all
DROP POLICY IF EXISTS "select_own_referrals" ON referrals;
CREATE POLICY "select_own_referrals"
ON referrals FOR SELECT
TO authenticated
USING (auth.uid() = referrer_id OR auth.uid() = referred_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Mining investments: admin can read all
DROP POLICY IF EXISTS "select_own_mining" ON mining_investments;
CREATE POLICY "select_own_mining"
ON mining_investments FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Deposit addresses: admin can update
DROP POLICY IF EXISTS "read_deposit_addresses" ON deposit_addresses;
CREATE POLICY "read_deposit_addresses"
ON deposit_addresses FOR SELECT
TO anon, authenticated
USING (true);

-- Add admin update policy for deposit_addresses
DROP POLICY IF EXISTS "admin_update_addresses" ON deposit_addresses;
CREATE POLICY "admin_update_addresses"
ON deposit_addresses FOR UPDATE
TO authenticated
USING (EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
))
WITH CHECK (EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- Investments: admin can read all
DROP POLICY IF EXISTS "select_own_investments" ON investments;
CREATE POLICY "select_own_investments"
ON investments FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));