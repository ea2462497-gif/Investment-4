/*
# Add sender_wallet column to deposits table

## Purpose
When two users deposit the same amount at the same time, the system needs a way
to distinguish which deposit belongs to which user. By storing the sender's
wallet address, the edge function can match blockchain transactions precisely:
it looks for a transaction FROM the user's wallet TO the platform's deposit address.

## Changes
1. Add column `sender_wallet` (text, nullable) to `deposits` table.
   - Nullable because old pending deposits don't have it.
   - New deposits will include the user's wallet address they will send from.

## Security
- No RLS policy changes needed (column is user-writable, same as other deposit columns).
- No grants changes needed (existing grants already cover all columns).
*/

ALTER TABLE deposits ADD COLUMN IF NOT EXISTS sender_wallet text DEFAULT '';
