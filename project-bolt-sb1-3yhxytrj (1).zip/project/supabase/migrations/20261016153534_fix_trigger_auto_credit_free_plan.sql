/*
 # Fix: Database trigger to auto-credit free plan profit on insert

 Instead of relying on client-side code, this trigger fires AFTER any
 mining_investments INSERT with plan_code='SNB-0' and automatically:
 1. Credits 1.6 USDT to the user's balance + total_profit
 2. Updates mining_investments.total_earned to 1.6
 3. Inserts a mining_profit transaction

 This works regardless of which client version is running.
*/

CREATE OR REPLACE FUNCTION public.handle_free_plan_profit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.plan_code = 'SNB-0' AND NEW.invest_amount = 0 THEN
    -- Credit 1.6 USDT to user's balance and total_profit
    UPDATE profiles
    SET balance = balance + 1.6,
        total_profit = total_profit + 1.6,
        updated_at = now()
    WHERE id = NEW.user_id;

    -- Update the mining investment's total_earned
    UPDATE mining_investments
    SET total_earned = 1.6
    WHERE id = NEW.id;

    -- Insert mining_profit transaction
    INSERT INTO transactions (user_id, type, amount, status, description)
    VALUES (NEW.user_id, 'mining_profit', 1.6, 'completed', 'Claim SNB-0 (1 day)');
  END IF;

  RETURN NEW;
END;
$$;

-- Drop existing trigger if any, then create
DROP TRIGGER IF EXISTS trg_free_plan_profit ON mining_investments;
CREATE TRIGGER trg_free_plan_profit
  AFTER INSERT ON mining_investments
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_free_plan_profit();
