-- Fix: admin balance updates silently fail because RLS update policy
-- on profiles may not reliably detect admin status from the subquery.
-- Create SECURITY DEFINER function for admin to update any user's balance.

CREATE OR REPLACE FUNCTION public.admin_update_balance(
  p_user_id uuid,
  p_balance numeric,
  p_total_invested numeric DEFAULT NULL,
  p_total_profit numeric DEFAULT NULL
)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE profiles
  SET 
    balance = p_balance,
    total_invested = COALESCE(p_total_invested, total_invested),
    total_profit = COALESCE(p_total_profit, total_profit),
    updated_at = now()
  WHERE id = p_user_id;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_update_balance(uuid, numeric, numeric, numeric) TO authenticated;

-- Fix: referral creation fails during signUp because the new user may not
-- have an active authenticated session yet. Create a SECURITY DEFINER function
-- that creates the referral record server-side.

CREATE OR REPLACE FUNCTION public.create_referral(
  p_referrer_code text,
  p_referred_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referrer_id uuid;
BEGIN
  SELECT id INTO v_referrer_id FROM profiles WHERE referral_code = p_referrer_code LIMIT 1;
  IF v_referrer_id IS NOT NULL AND v_referrer_id != p_referred_id THEN
    INSERT INTO referrals (referrer_id, referred_id, referral_code, reward, status)
    VALUES (v_referrer_id, p_referred_id, p_referrer_code, 5, 'pending')
    ON CONFLICT DO NOTHING;
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_referral(text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_referral(text, uuid) TO authenticated, anon;
