-- Fix: new users can't look up referrer by referral_code because
-- RLS on profiles blocks reading other users' rows.
-- Create a SECURITY DEFINER function that finds referrer by code.

CREATE OR REPLACE FUNCTION public.get_referrer_by_code(p_code text)
RETURNS TABLE (id uuid)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM profiles WHERE referral_code = p_code LIMIT 1;
$$;

REVOKE EXECUTE ON FUNCTION public.get_referrer_by_code(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_referrer_by_code(text) TO authenticated;
