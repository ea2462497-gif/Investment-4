/*
 # Fix: new users get empty referral_code

 ## Root cause
 1. signUp calls generate_referral_code() → sometimes returns null or fails
 2. create_user_profile receives empty string for p_referral_code
 3. ON CONFLICT DO UPDATE sets referral_code = profiles.referral_code (preserves existing)
 4. But on first INSERT, the empty string is stored → code stays "" forever

 ## Fix
 1. create_user_profile: if p_referral_code is empty, generate one automatically
    using generate_referral_code() inside the function
 2. Also add a trigger as a safety net: if referral_code is empty on INSERT,
    auto-generate one
*/

CREATE OR REPLACE FUNCTION public.create_user_profile(
  p_user_id uuid,
  p_full_name text DEFAULT '',
  p_phone text DEFAULT '',
  p_referral_code text DEFAULT '',
  p_referred_by text DEFAULT ''
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_code text;
BEGIN
  -- If no referral code provided, generate one
  IF p_referral_code IS NULL OR p_referral_code = '' THEN
    v_code := public.generate_referral_code();
  ELSE
    v_code := p_referral_code;
  END IF;

  INSERT INTO profiles (id, full_name, phone, referral_code, referred_by)
  VALUES (p_user_id, p_full_name, p_phone, v_code, p_referred_by)
  ON CONFLICT (id) DO UPDATE SET
    full_name = COALESCE(NULLIF(p_full_name, ''), profiles.full_name),
    phone = COALESCE(NULLIF(p_phone, ''), profiles.phone),
    referral_code = profiles.referral_code,
    referred_by = COALESCE(NULLIF(p_referred_by, ''), profiles.referred_by),
    updated_at = now();
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_user_profile(uuid, text, text, text, text) TO authenticated, anon;

-- Safety net trigger: auto-generate referral_code if empty on INSERT
CREATE OR REPLACE FUNCTION public.ensure_referral_code()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.referral_code IS NULL OR NEW.referral_code = '' THEN
    NEW.referral_code := public.generate_referral_code();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_ensure_referral_code ON profiles;
CREATE TRIGGER trg_ensure_referral_code
  BEFORE INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.ensure_referral_code();

REVOKE EXECUTE ON FUNCTION public.ensure_referral_code() FROM PUBLIC;

-- Fix existing users with empty referral codes
UPDATE profiles
SET referral_code = public.generate_referral_code()
WHERE referral_code IS NULL OR referral_code = '';
