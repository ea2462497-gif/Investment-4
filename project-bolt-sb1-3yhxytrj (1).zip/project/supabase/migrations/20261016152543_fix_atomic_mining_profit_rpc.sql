/*
 # Fix: Create atomic RPC to credit mining profit directly in the database

 The client-side profile update was failing silently because:
 1. profile?.balance might be stale/null
 2. RLS policy on profiles calls is_current_user_admin() which queries profiles
    during an UPDATE — can cause subtle issues

 This RPC (SECURITY DEFINER) does it atomically: adds profit to balance + total_profit,
 updates mining_investments.total_earned, and inserts a transaction — all in one call.
*/

CREATE OR REPLACE FUNCTION public.claim_mining_profit(
  p_mining_id uuid,
  p_days int DEFAULT 1
)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inv RECORD;
  v_earnings numeric;
BEGIN
  SELECT * INTO v_inv FROM mining_investments WHERE id = p_mining_id AND status = 'active';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Mining investment not found or not active';
  END IF;

  -- Verify caller owns this investment
  IF v_inv.user_id != auth.uid() THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  v_earnings := v_inv.daily_earn * p_days;
  IF v_earnings <= 0 THEN
    RETURN 0;
  END IF;

  -- Update mining investment
  UPDATE mining_investments
  SET last_claim = now(), total_earned = total_earned + v_earnings
  WHERE id = p_mining_id;

  -- Credit balance + profit
  UPDATE profiles
  SET balance = balance + v_earnings,
      total_profit = total_profit + v_earnings,
      updated_at = now()
  WHERE id = v_inv.user_id;

  -- Record transaction
  INSERT INTO transactions (user_id, type, amount, status, description)
  VALUES (v_inv.user_id, 'mining_profit', v_earnings, 'completed',
    'Claim ' || v_inv.plan_code || ' (' || p_days || ' day)');

  RETURN v_earnings;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_mining_profit(uuid, int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.claim_mining_profit(uuid, int) TO authenticated;


-- Also create a simpler RPC for the free plan activation that credits profit immediately
CREATE OR REPLACE FUNCTION public.activate_free_plan()
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_inv_id uuid;
  v_daily numeric := 1.6;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Check if already has an active SNB-0
  SELECT id INTO v_inv_id FROM mining_investments
  WHERE user_id = v_user_id AND plan_code = 'SNB-0' AND status = 'active';

  IF v_inv_id IS NOT NULL THEN
    -- Already active, credit profit if total_earned = 0
    UPDATE mining_investments
    SET total_earned = total_earned + v_daily, last_claim = now()
    WHERE id = v_inv_id AND total_earned = 0;

    IF FOUND THEN
      UPDATE profiles SET balance = balance + v_daily, total_profit = total_profit + v_daily, updated_at = now()
      WHERE id = v_user_id;

      INSERT INTO transactions (user_id, type, amount, status, description)
      VALUES (v_user_id, 'mining_profit', v_daily, 'completed', 'Claim SNB-0 (1 day)');

      RETURN v_daily;
    END IF;

    RETURN 0; -- already credited
  END IF;

  -- Insert new mining investment
  INSERT INTO mining_investments (user_id, plan_code, invest_amount, daily_earn, status, last_claim)
  VALUES (v_user_id, 'SNB-0', 0, v_daily, 'active', now())
  RETURNING id INTO v_inv_id;

  -- Credit first day profit
  UPDATE mining_investments SET total_earned = v_daily WHERE id = v_inv_id;

  UPDATE profiles SET balance = balance + v_daily, total_profit = total_profit + v_daily, updated_at = now()
  WHERE id = v_user_id;

  INSERT INTO transactions (user_id, type, amount, status, description)
  VALUES (v_user_id, 'mining_profit', v_daily, 'completed', 'Claim SNB-0 (1 day)');

  RETURN v_daily;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.activate_free_plan() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.activate_free_plan() TO authenticated;
