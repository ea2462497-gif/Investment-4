-- Enable realtime on profiles so balance changes are pushed to the client
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
