-- Fix generate_referral_code to use SNB prefix (was RAS, mismatching existing codes)
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 'SNB' || UPPER(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
$$;

REVOKE EXECUTE ON FUNCTION public.generate_referral_code() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.generate_referral_code() TO authenticated, anon;
